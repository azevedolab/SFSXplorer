#!/usr/bin/env python3
#
################################################################################
# SFSXplorer                                                                   #
# Scoring Function Space eXplorer                                              #
################################################################################
#
# Program to calculate intermolecular potential based on atomic coordinates in
# the PDBQT format.
# It uses pair-wise energetic terms of the AutoDock4 progam (Morris et al.,
# 1998; 2009).
#
#
# References:
#
# Morris GM, Goodsell D, Halliday R, Huey R, Hart W, Belew R, Olson A. Automated
# docking using a Lamarckian genetic algorithm and an empirical binding free
# energy function. J Comput Chem. 1998; 19:1639-1662.
#
# Morris GM, Huey R, Lindstrom W, Sanner MF, Belew RK, Goodsell DS, Olson AJ.
# AutoDock4 and AutoDockTools4: Automated docking with selective receptor
# flexibility. J Comput Chem. 2009 Dec;30(16):2785-91. doi: 10.1002/jcc.21256.
# PMID: 19399780; PMCID: PMC2760638.
#
################################################################################
# Dr. Walter F. de Azevedo, Jr.                                                #
# https://azevedolab.net/                                                      #
# January 12, 2023                                                             #
################################################################################
#
# Import section
import numpy as np

# Define PairwisePotSol() class
class PairwisePotSol(object):
    """Class to calculate pairwise potential energy for solvatation based on
    the Autodock4 force field"""

    # Define potential() method
    def potential(self,vol_i,sol_i,vol_j,sol_j,r,m,n,sigma):
        """Method to calculate pairwise potential energy based on the
        Autodock4 force field"""

        # Calculate v(r)
        v = ((vol_i*sol_i) + (vol_j*sol_j))*np.exp(-r**n/(2*sigma**m))

        # Return result
        return v
