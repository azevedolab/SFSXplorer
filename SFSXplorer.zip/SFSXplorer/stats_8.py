#!/usr/bin/python
#
# Class to calculate Spearman and Pearson correlation coefficients.
# 
# Walter F. de Azevedo Jr.
# February 8, 2019
# https://azevedolab.net
#
# Reference:
# Zar JH (1972) Significance Testing of the Spearman Rank Correlation Coefficient. J Am Stat Assoc 67(339):578-580
#
# Define class
class StatsAnalysis(object):
    """Classo to carry correlation analysis"""

    # Set constructor method
    def __init__(self,x,Y):
        """Constructor method"""

        # Define attributes
        self.x = x
        self.Y = Y

    # Define rho method
    def rho(self):
        """Method to calculate Spearman's rank correlation coefficient"""
        
        from scipy import stats
        s,pvalue = stats.spearmanr(self.x,self.Y)
        return(s,pvalue)

    # Define pearson method
    def pearson_corr(self):
        """Method to calculate Pearson's correlation coefficient"""

        from scipy import stats
        
        r,pvalue =  stats.pearsonr(self.x,self.Y)
        
        return(r,pvalue)


