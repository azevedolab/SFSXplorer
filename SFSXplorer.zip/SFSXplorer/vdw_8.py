#!/usr/bin/python
# Program to calculate intermolecular potential based on atomic coordinates in the PDBQT format
# It uses pair-wise energetic terms of the AutoDock4 progam (Morris et al., 1998).
# 
# Walter F. de Azevedo Jr.
# February 8, 2019
# azevedolab.net
#
# Reference:
# Morris G, Goodsell D, Halliday R, Huey R, Hart W, Belew R, Olson A. Automated docking using a
# Lamarckian genetic algorithm and an empirical binding free energy function. J Comput Chem. 1998; # 19:1639-1662. 
#
# Define class
class PairwisePot(object):
    """Class to calculate pairwise potential energy based on the Lennard-Jones equation"""
        
    # Define potential() method
    def potential(self,reqm_i,epsilon_i,reqm_j,epsilon_j,r,m,n):
        """Method to calculate pairwise potential energy based on the Lennard-Jones equation"""
        
        # Import library
        import numpy as np
        
        # To obtain the Rij value for non H-bonding atoms
        reqm = 0.5*(reqm_i+reqm_j)
        
        #  To obtain the epsilon value for non H-bonding atoms
        epsilon = np.sqrt(epsilon_i*epsilon_j)
        
        # Calculate cm and cn parameters if n != m
        if n != m:
            cm = (n/(n-m))*epsilon*reqm**m 
            cn = (m/(n-m))*epsilon*reqm**n
        else:
            return None,None,None
                
        # Calculate v(r)        
        v = cn/r**n - cm/r**m
        
        # Return results
        return cn,cm,v
