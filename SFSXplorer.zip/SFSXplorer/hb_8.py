#!/usr/bin/python
# Program to calculate intermolecular potential based on atomic coordinates in the PDBQT format
# It uses pair-wise energetic terms of the AutoDock4 progam (Morris et al., 1998).
# 
# 
# Walter F. de Azevedo Jr.
# February 8, 2019
# https://azevedolab.net
#
# Reference:
# Morris G, Goodsell D, Halliday R, Huey R, Hart W, Belew R, Olson A. Automated docking using a
# Lamarckian genetic algorithm and an empirical binding free energy function. J Comput Chem. 1998; # 19:1639-1662. 
#
# Define class
class PairwisePotHB(object):
    """Class to calculate pairwise potential energy for hydrogen bonds based on the autodock equation"""
    
    # Define potential() method
    def potential(self,reqm_i,epsilon_i,reqm_j,epsilon_j,r,m,n):
        """Method to calculate pairwise potential energy based on the AutoDock equation"""
        
        # Import library
        import numpy as np
        
        # To obtain the Rij value for H-bonding atoms
        if reqm_i > reqm_j:
            reqm = reqm_i
        elif reqm_i < reqm_j:
            reqm = reqm_j
        else:
            reqm = reqm_i
        
        #  To obtain the epsilon value for H-bonding atoms
        if epsilon_i > epsilon_j:
            epsilon = epsilon_i
        elif epsilon_i < epsilon_j:
            epsilon = epsilon_j
        else:
            epsilon = epsilon_i
        
        # Calculate cm and cn parameters if n != m
        if n != m:
            cm = (n/(n-m))*epsilon*reqm**m 
            cn = (m/(n-m))*epsilon*reqm**n
        else:
            return None,None,None
                
        # Calculate v(r)     
        v = cn/r**n - cm/r**m
        
        # Return results
        return cn,cm,v
