#!/usr/bin/python
# This program calculates energy terms available in the AutoDock 4 semiempirical force field to explore
# the scoring function space.
#
# Walter F. de Azevedo Jr.
# February 8, 2019
# https://azevedolab.net
#
# Reference:
# Morris G, Goodsell D, Halliday R, Huey R, Hart W, Belew R, Olson A. Automated docking using a
# Lamarckian genetic algorithm and an empirical binding free energy function. J Comput Chem. 1998; # 19:1639-1662. 
#
# Set SFexplorer class
class SFexplorer(object):
    """A class to explore the scoring function space"""	

    # Define the constructor method
    def __init__(self):
        """Constructor method"""

        # Set up attributes
        self.chklig_in = "chklig.in"
        self.scores_out = "scores_out.csv"
        self.sandres_out = "sandres_out.csv"
        self.binding_type = "ki"

    # Define read_input() method
    def read_input(self):
        """Method to read input data"""

        # Import libraries
        import csv
		
        # Open sfs.in file
        fo = open("sfs.in","r")
        csv = csv.reader(fo)

        # Looping through sfs.in
        for line in csv:
            if line[0] == "chklig_in":
                self.chklig_in = str(line[1])
            elif line[0] == "dataset_dir":
                self.dataset_dir = str(line[1])
            elif line[0] == "scores_out":
                self.scores_out = str(line[1])
            elif line[0] == "sandres_out":
                self.sandres_out = str(line[1])
            elif line[0] == "binding_type":
                self.binding_type = str(line[1])

        # Close file
        fo.close()
        
    # Define read_data() method
    def read_data(self):
        """Method to read data chklig.in"""

        # Import libraries
        import csv
		
        # Open chklig.in
        self.fo0 = open(self.chklig_in,"r")
        self.csv0 = csv.reader(self.fo0)

    # Define write_energy() method
    def write_energy(self):
        """Method to write energy terms"""
        
        # Import libraries
        import numpy as np
        import FF_AD4_8 as ad4

        # Open scores_ff_all.csv
        self.fo2 = open(self.scores_out,"w")

        # Open scores_ff_sandres.csv
        self.fo3 = open(self.sandres_out,"w")
        
        # Open scores_ff_LJ.csv
        self.fo4 = open(self.scores_out[:len(self.scores_out)-7]+"LJ.csv","w")
        
        # Open scores_ff_HB.csv
        self.fo5 = open(self.scores_out[:len(self.scores_out)-7]+"HB.csv","w")
        
        # Open scores_ff_sandres_LJ.csv
        self.fo6 = open(self.sandres_out[:len(self.sandres_out)-4]+"_LJ.csv","w")
        
        # Open scores_ff_sandres_LJ.csv
        self.fo7 = open(self.sandres_out[:len(self.sandres_out)-4]+"_HB.csv","w")

        # Set up headers for Lennard-Jones potentials
        headers_LJ = ""+\
        "v_LJ_32_2,v_LJ_32_3,v_LJ_32_4,v_LJ_32_5,v_LJ_32_6,v_LJ_32_7,v_LJ_32_8,v_LJ_32_9,v_LJ_32_10,v_LJ_32_11,v_LJ_32_12,"+\
        "v_LJ_32_13,v_LJ_32_14,v_LJ_32_15,v_LJ_32_16,v_LJ_32_17,v_LJ_32_18,v_LJ_32_19,v_LJ_32_20,v_LJ_32_21,v_LJ_32_22,"+\
        "v_LJ_32_23,v_LJ_32_24,v_LJ_32_25,v_LJ_32_26,v_LJ_32_27,v_LJ_32_28,v_LJ_32_29,v_LJ_32_30,v_LJ_32_31,"+\
        "v_LJ_31_2,v_LJ_31_3,v_LJ_31_4,v_LJ_31_5,v_LJ_31_6,v_LJ_31_7,v_LJ_31_8,v_LJ_31_9,v_LJ_31_10,v_LJ_31_11,v_LJ_31_12,"+\
        "v_LJ_31_13,v_LJ_31_14,v_LJ_31_15,v_LJ_31_16,v_LJ_31_17,v_LJ_31_18,v_LJ_31_19,v_LJ_31_20,v_LJ_31_21,v_LJ_31_22,"+\
        "v_LJ_31_23,v_LJ_31_24,v_LJ_31_25,v_LJ_31_26,v_LJ_31_27,v_LJ_31_28,v_LJ_31_29,v_LJ_31_30,"+\
        "v_LJ_30_2,v_LJ_30_3,v_LJ_30_4,v_LJ_30_5,v_LJ_30_6,v_LJ_30_7,v_LJ_30_8,v_LJ_30_9,v_LJ_30_10,v_LJ_30_11,v_LJ_30_12,"+\
        "v_LJ_30_13,v_LJ_30_14,v_LJ_30_15,v_LJ_30_16,v_LJ_30_17,v_LJ_30_18,v_LJ_30_19,v_LJ_30_20,v_LJ_30_21,v_LJ_30_22,"+\
        "v_LJ_30_23,v_LJ_30_24,v_LJ_30_25,v_LJ_30_26,v_LJ_30_27,v_LJ_30_28,v_LJ_30_29,"+\
        "v_LJ_29_2,v_LJ_29_3,v_LJ_29_4,v_LJ_29_5,v_LJ_29_6,v_LJ_29_7,v_LJ_29_8,v_LJ_29_9,v_LJ_29_10,v_LJ_29_11,v_LJ_29_12,"+\
        "v_LJ_29_13,v_LJ_29_14,v_LJ_29_15,v_LJ_29_16,v_LJ_29_17,v_LJ_29_18,v_LJ_29_19,v_LJ_29_20,v_LJ_29_21,v_LJ_29_22,"+\
        "v_LJ_29_23,v_LJ_29_24,v_LJ_29_25,v_LJ_29_26,v_LJ_29_27,v_LJ_29_28,"+\
        "v_LJ_28_2,v_LJ_28_3,v_LJ_28_4,v_LJ_28_5,v_LJ_28_6,v_LJ_28_7,v_LJ_28_8,v_LJ_28_9,v_LJ_28_10,v_LJ_28_11,v_LJ_28_12,"+\
        "v_LJ_28_13,v_LJ_28_14,v_LJ_28_15,v_LJ_28_16,v_LJ_28_17,v_LJ_28_18,v_LJ_28_19,v_LJ_28_20,v_LJ_28_21,v_LJ_28_22,"+\
        "v_LJ_28_23,v_LJ_28_24,v_LJ_28_25,v_LJ_28_26,v_LJ_28_27,"+\
        "v_LJ_27_2,v_LJ_27_3,v_LJ_27_4,v_LJ_27_5,v_LJ_27_6,v_LJ_27_7,v_LJ_27_8,v_LJ_27_9,v_LJ_27_10,v_LJ_27_11,v_LJ_27_12,"+\
        "v_LJ_27_13,v_LJ_27_14,v_LJ_27_15,v_LJ_27_16,v_LJ_27_17,v_LJ_27_18,v_LJ_27_19,v_LJ_27_20,v_LJ_27_21,v_LJ_27_22,"+\
        "v_LJ_27_23,v_LJ_27_24,v_LJ_27_25,v_LJ_27_26,"+\
        "v_LJ_26_2,v_LJ_26_3,v_LJ_26_4,v_LJ_26_5,v_LJ_26_6,v_LJ_26_7,v_LJ_26_8,v_LJ_26_9,v_LJ_26_10,v_LJ_26_11,v_LJ_26_12,"+\
        "v_LJ_26_13,v_LJ_26_14,v_LJ_26_15,v_LJ_26_16,v_LJ_26_17,v_LJ_26_18,v_LJ_26_19,v_LJ_26_20,v_LJ_26_21,v_LJ_26_22,"+\
        "v_LJ_26_23,v_LJ_26_24,v_LJ_26_25,"+\
        "v_LJ_25_2,v_LJ_25_3,v_LJ_25_4,v_LJ_25_5,v_LJ_25_6,v_LJ_25_7,v_LJ_25_8,v_LJ_25_9,v_LJ_25_10,v_LJ_25_11,v_LJ_25_12,"+\
        "v_LJ_25_13,v_LJ_25_14,v_LJ_25_15,v_LJ_25_16,v_LJ_25_17,v_LJ_25_18,v_LJ_25_19,v_LJ_25_20,v_LJ_25_21,v_LJ_25_22,"+\
        "v_LJ_25_23,v_LJ_25_24,"+\
        "v_LJ_24_2,v_LJ_24_3,v_LJ_24_4,v_LJ_24_5,v_LJ_24_6,v_LJ_24_7,v_LJ_24_8,v_LJ_24_9,v_LJ_24_10,v_LJ_24_11,v_LJ_24_12,"+\
        "v_LJ_24_13,v_LJ_24_14,v_LJ_24_15,v_LJ_24_16,v_LJ_24_17,v_LJ_24_18,v_LJ_24_19,v_LJ_24_20,v_LJ_24_21,v_LJ_24_22,"+\
        "v_LJ_24_23,"+\
        "v_LJ_23_2,v_LJ_23_3,v_LJ_23_4,v_LJ_23_5,v_LJ_23_6,v_LJ_23_7,v_LJ_23_8,v_LJ_23_9,v_LJ_23_10,v_LJ_23_11,v_LJ_23_12,"+\
        "v_LJ_23_13,v_LJ_23_14,v_LJ_23_15,v_LJ_23_16,v_LJ_23_17,v_LJ_23_18,v_LJ_23_19,v_LJ_23_20,v_LJ_23_21,v_LJ_23_22,"+\
        "v_LJ_22_2,v_LJ_22_3,v_LJ_22_4,v_LJ_22_5,v_LJ_22_6,v_LJ_22_7,v_LJ_22_8,v_LJ_22_9,v_LJ_22_10,v_LJ_22_11,v_LJ_22_12,"+\
        "v_LJ_22_13,v_LJ_22_14,v_LJ_22_15,v_LJ_22_16,v_LJ_22_17,v_LJ_22_18,v_LJ_22_19,v_LJ_22_20,v_LJ_22_21,"+\
        "v_LJ_21_2,v_LJ_21_3,v_LJ_21_4,v_LJ_21_5,v_LJ_21_6,v_LJ_21_7,v_LJ_21_8,v_LJ_21_9,v_LJ_21_10,v_LJ_21_11,v_LJ_21_12,"+\
        "v_LJ_21_13,v_LJ_21_14,v_LJ_21_15,v_LJ_21_16,v_LJ_21_17,v_LJ_21_18,v_LJ_21_19,v_LJ_21_20,"+\
        "v_LJ_20_2,v_LJ_20_3,v_LJ_20_4,v_LJ_20_5,v_LJ_20_6,v_LJ_20_7,v_LJ_20_8,v_LJ_20_9,v_LJ_20_10,v_LJ_20_11,v_LJ_20_12,"+\
        "v_LJ_20_13,v_LJ_20_14,v_LJ_20_15,v_LJ_20_16,v_LJ_20_17,v_LJ_20_18,v_LJ_20_19,"+\
        "v_LJ_19_2,v_LJ_19_3,v_LJ_19_4,v_LJ_19_5,v_LJ_19_6,v_LJ_19_7,v_LJ_19_8,v_LJ_19_9,v_LJ_19_10,v_LJ_19_11,v_LJ_19_12,"+\
        "v_LJ_19_13,v_LJ_19_14,v_LJ_19_15,v_LJ_19_16,v_LJ_19_17,v_LJ_19_18,"+\
        "v_LJ_18_2,v_LJ_18_3,v_LJ_18_4,v_LJ_18_5,v_LJ_18_6,v_LJ_18_7,v_LJ_18_8,v_LJ_18_9,v_LJ_18_10,v_LJ_18_11,v_LJ_18_12,"+\
        "v_LJ_18_13,v_LJ_18_14,v_LJ_18_15,v_LJ_18_16,v_LJ_18_17,"+\
        "v_LJ_17_2,v_LJ_17_3,v_LJ_17_4,v_LJ_17_5,v_LJ_17_6,v_LJ_17_7,v_LJ_17_8,v_LJ_17_9,v_LJ_17_10,v_LJ_17_11,v_LJ_17_12,"+\
        "v_LJ_17_13,v_LJ_17_14,v_LJ_17_15,v_LJ_17_16,"+\
        "v_LJ_16_2,v_LJ_16_3,v_LJ_16_4,v_LJ_16_5,v_LJ_16_6,v_LJ_16_7,v_LJ_16_8,v_LJ_16_9,v_LJ_16_10,v_LJ_16_11,v_LJ_16_12,"+\
        "v_LJ_16_13,v_LJ_16_14,v_LJ_16_15,"+\
        "v_LJ_15_2,v_LJ_15_3,v_LJ_15_4,v_LJ_15_5,v_LJ_15_6,v_LJ_15_7,v_LJ_15_8,v_LJ_15_9,v_LJ_15_10,v_LJ_15_11,v_LJ_15_12,"+\
        "v_LJ_15_13,v_LJ_15_14,"+\
        "v_LJ_14_2,v_LJ_14_3,v_LJ_14_4,v_LJ_14_5,v_LJ_14_6,v_LJ_14_7,v_LJ_14_8,v_LJ_14_9,v_LJ_14_10,v_LJ_14_11,v_LJ_14_12,"+\
        "v_LJ_14_13,"+\
        "v_LJ_13_2,v_LJ_13_3,v_LJ_13_4,v_LJ_13_5,v_LJ_13_6,v_LJ_13_7,v_LJ_13_8,v_LJ_13_9,v_LJ_13_10,v_LJ_13_11,v_LJ_13_12,"+\
        "v_LJ_12_2,v_LJ_12_3,v_LJ_12_4,v_LJ_12_5,v_LJ_12_6,v_LJ_12_7,v_LJ_12_8,v_LJ_12_9,v_LJ_12_10,v_LJ_12_11,"+\
        "v_LJ_11_2,v_LJ_11_3,v_LJ_11_4,v_LJ_11_5,v_LJ_11_6,v_LJ_11_7,v_LJ_11_8,v_LJ_11_9,v_LJ_11_10,"+\
        "v_LJ_10_2,v_LJ_10_3,v_LJ_10_4,v_LJ_10_5,v_LJ_10_6,v_LJ_10_7,v_LJ_10_8,v_LJ_10_9,"+\
        "v_LJ_9_2,v_LJ_9_3,v_LJ_9_4,v_LJ_9_5,v_LJ_9_6,v_LJ_9_7,v_LJ_9_8,"+\
        "v_LJ_8_2,v_LJ_8_3,v_LJ_8_4,v_LJ_8_5,v_LJ_8_6,v_LJ_8_7,"+\
        "v_LJ_7_2,v_LJ_7_3,v_LJ_7_4,v_LJ_7_5,v_LJ_7_6,"+\
        "v_LJ_6_2,v_LJ_6_3,v_LJ_6_4,v_LJ_6_5,"+\
        "v_LJ_5_2,v_LJ_5_3,v_LJ_5_4,"+\
        "v_LJ_4_2,v_LJ_4_3,"+\
        "v_LJ_3_2,"
        
        # Set up headers for hydrogen-bond potentials
        headers_HB = ""+\
        "v_HB_32_2,v_HB_32_3,v_HB_32_4,v_HB_32_5,v_HB_32_6,v_HB_32_7,v_HB_32_8,v_HB_32_9,v_HB_32_10,v_HB_32_11,v_HB_32_12,"+\
        "v_HB_32_13,v_HB_32_14,v_HB_32_15,v_HB_32_16,v_HB_32_17,v_HB_32_18,v_HB_32_19,v_HB_32_20,v_HB_32_21,v_HB_32_22,"+\
        "v_HB_32_23,v_HB_32_24,v_HB_32_25,v_HB_32_26,v_HB_32_27,v_HB_32_28,v_HB_32_29,v_HB_32_30,v_HB_32_31,"+\
        "v_HB_31_2,v_HB_31_3,v_HB_31_4,v_HB_31_5,v_HB_31_6,v_HB_31_7,v_HB_31_8,v_HB_31_9,v_HB_31_10,v_HB_31_11,v_HB_31_12,"+\
        "v_HB_31_13,v_HB_31_14,v_HB_31_15,v_HB_31_16,v_HB_31_17,v_HB_31_18,v_HB_31_19,v_HB_31_20,v_HB_31_21,v_HB_31_22,"+\
        "v_HB_31_23,v_HB_31_24,v_HB_31_25,v_HB_31_26,v_HB_31_27,v_HB_31_28,v_HB_31_29,v_HB_31_30,"+\
        "v_HB_30_2,v_HB_30_3,v_HB_30_4,v_HB_30_5,v_HB_30_6,v_HB_30_7,v_HB_30_8,v_HB_30_9,v_HB_30_10,v_HB_30_11,v_HB_30_12,"+\
        "v_HB_30_13,v_HB_30_14,v_HB_30_15,v_HB_30_16,v_HB_30_17,v_HB_30_18,v_HB_30_19,v_HB_30_20,v_HB_30_21,v_HB_30_22,"+\
        "v_HB_30_23,v_HB_30_24,v_HB_30_25,v_HB_30_26,v_HB_30_27,v_HB_30_28,v_HB_30_29,"+\
        "v_HB_29_2,v_HB_29_3,v_HB_29_4,v_HB_29_5,v_HB_29_6,v_HB_29_7,v_HB_29_8,v_HB_29_9,v_HB_29_10,v_HB_29_11,v_HB_29_12,"+\
        "v_HB_29_13,v_HB_29_14,v_HB_29_15,v_HB_29_16,v_HB_29_17,v_HB_29_18,v_HB_29_19,v_HB_29_20,v_HB_29_21,v_HB_29_22,"+\
        "v_HB_29_23,v_HB_29_24,v_HB_29_25,v_HB_29_26,v_HB_29_27,v_HB_29_28,"+\
        "v_HB_28_2,v_HB_28_3,v_HB_28_4,v_HB_28_5,v_HB_28_6,v_HB_28_7,v_HB_28_8,v_HB_28_9,v_HB_28_10,v_HB_28_11,v_HB_28_12,"+\
        "v_HB_28_13,v_HB_28_14,v_HB_28_15,v_HB_28_16,v_HB_28_17,v_HB_28_18,v_HB_28_19,v_HB_28_20,v_HB_28_21,v_HB_28_22,"+\
        "v_HB_28_23,v_HB_28_24,v_HB_28_25,v_HB_28_26,v_HB_28_27,"+\
        "v_HB_27_2,v_HB_27_3,v_HB_27_4,v_HB_27_5,v_HB_27_6,v_HB_27_7,v_HB_27_8,v_HB_27_9,v_HB_27_10,v_HB_27_11,v_HB_27_12,"+\
        "v_HB_27_13,v_HB_27_14,v_HB_27_15,v_HB_27_16,v_HB_27_17,v_HB_27_18,v_HB_27_19,v_HB_27_20,v_HB_27_21,v_HB_27_22,"+\
        "v_HB_27_23,v_HB_27_24,v_HB_27_25,v_HB_27_26,"+\
        "v_HB_26_2,v_HB_26_3,v_HB_26_4,v_HB_26_5,v_HB_26_6,v_HB_26_7,v_HB_26_8,v_HB_26_9,v_HB_26_10,v_HB_26_11,v_HB_26_12,"+\
        "v_HB_26_13,v_HB_26_14,v_HB_26_15,v_HB_26_16,v_HB_26_17,v_HB_26_18,v_HB_26_19,v_HB_26_20,v_HB_26_21,v_HB_26_22,"+\
        "v_HB_26_23,v_HB_26_24,v_HB_26_25,"+\
        "v_HB_25_2,v_HB_25_3,v_HB_25_4,v_HB_25_5,v_HB_25_6,v_HB_25_7,v_HB_25_8,v_HB_25_9,v_HB_25_10,v_HB_25_11,v_HB_25_12,"+\
        "v_HB_25_13,v_HB_25_14,v_HB_25_15,v_HB_25_16,v_HB_25_17,v_HB_25_18,v_HB_25_19,v_HB_25_20,v_HB_25_21,v_HB_25_22,"+\
        "v_HB_25_23,v_HB_25_24,"+\
        "v_HB_24_2,v_HB_24_3,v_HB_24_4,v_HB_24_5,v_HB_24_6,v_HB_24_7,v_HB_24_8,v_HB_24_9,v_HB_24_10,v_HB_24_11,v_HB_24_12,"+\
        "v_HB_24_13,v_HB_24_14,v_HB_24_15,v_HB_24_16,v_HB_24_17,v_HB_24_18,v_HB_24_19,v_HB_24_20,v_HB_24_21,v_HB_24_22,"+\
        "v_HB_24_23,"+\
        "v_HB_23_2,v_HB_23_3,v_HB_23_4,v_HB_23_5,v_HB_23_6,v_HB_23_7,v_HB_23_8,v_HB_23_9,v_HB_23_10,v_HB_23_11,v_HB_23_12,"+\
        "v_HB_23_13,v_HB_23_14,v_HB_23_15,v_HB_23_16,v_HB_23_17,v_HB_23_18,v_HB_23_19,v_HB_23_20,v_HB_23_21,v_HB_23_22,"+\
        "v_HB_22_2,v_HB_22_3,v_HB_22_4,v_HB_22_5,v_HB_22_6,v_HB_22_7,v_HB_22_8,v_HB_22_9,v_HB_22_10,v_HB_22_11,v_HB_22_12,"+\
        "v_HB_22_13,v_HB_22_14,v_HB_22_15,v_HB_22_16,v_HB_22_17,v_HB_22_18,v_HB_22_19,v_HB_22_20,v_HB_22_21,"+\
        "v_HB_21_2,v_HB_21_3,v_HB_21_4,v_HB_21_5,v_HB_21_6,v_HB_21_7,v_HB_21_8,v_HB_21_9,v_HB_21_10,v_HB_21_11,v_HB_21_12,"+\
        "v_HB_21_13,v_HB_21_14,v_HB_21_15,v_HB_21_16,v_HB_21_17,v_HB_21_18,v_HB_21_19,v_HB_21_20,"+\
        "v_HB_20_2,v_HB_20_3,v_HB_20_4,v_HB_20_5,v_HB_20_6,v_HB_20_7,v_HB_20_8,v_HB_20_9,v_HB_20_10,v_HB_20_11,v_HB_20_12,"+\
        "v_HB_20_13,v_HB_20_14,v_HB_20_15,v_HB_20_16,v_HB_20_17,v_HB_20_18,v_HB_20_19,"+\
        "v_HB_19_2,v_HB_19_3,v_HB_19_4,v_HB_19_5,v_HB_19_6,v_HB_19_7,v_HB_19_8,v_HB_19_9,v_HB_19_10,v_HB_19_11,v_HB_19_12,"+\
        "v_HB_19_13,v_HB_19_14,v_HB_19_15,v_HB_19_16,v_HB_19_17,v_HB_19_18,"+\
        "v_HB_18_2,v_HB_18_3,v_HB_18_4,v_HB_18_5,v_HB_18_6,v_HB_18_7,v_HB_18_8,v_HB_18_9,v_HB_18_10,v_HB_18_11,v_HB_18_12,"+\
        "v_HB_18_13,v_HB_18_14,v_HB_18_15,v_HB_18_16,v_HB_18_17,"+\
        "v_HB_17_2,v_HB_17_3,v_HB_17_4,v_HB_17_5,v_HB_17_6,v_HB_17_7,v_HB_17_8,v_HB_17_9,v_HB_17_10,v_HB_17_11,v_HB_17_12,"+\
        "v_HB_17_13,v_HB_17_14,v_HB_17_15,v_HB_17_16,"+\
        "v_HB_16_2,v_HB_16_3,v_HB_16_4,v_HB_16_5,v_HB_16_6,v_HB_16_7,v_HB_16_8,v_HB_16_9,v_HB_16_10,v_HB_16_11,v_HB_16_12,"+\
        "v_HB_16_13,v_HB_16_14,v_HB_16_15,"+\
        "v_HB_15_2,v_HB_15_3,v_HB_15_4,v_HB_15_5,v_HB_15_6,v_HB_15_7,v_HB_15_8,v_HB_15_9,v_HB_15_10,v_HB_15_11,v_HB_15_12,"+\
        "v_HB_15_13,v_HB_15_14,"+\
        "v_HB_14_2,v_HB_14_3,v_HB_14_4,v_HB_14_5,v_HB_14_6,v_HB_14_7,v_HB_14_8,v_HB_14_9,v_HB_14_10,v_HB_14_11,v_HB_14_12,"+\
        "v_HB_14_13,"+\
        "v_HB_13_2,v_HB_13_3,v_HB_13_4,v_HB_13_5,v_HB_13_6,v_HB_13_7,v_HB_13_8,v_HB_13_9,v_HB_13_10,v_HB_13_11,v_HB_13_12,"+\
        "v_HB_12_2,v_HB_12_3,v_HB_12_4,v_HB_12_5,v_HB_12_6,v_HB_12_7,v_HB_12_8,v_HB_12_9,v_HB_12_10,v_HB_12_11,"+\
        "v_HB_11_2,v_HB_11_3,v_HB_11_4,v_HB_11_5,v_HB_11_6,v_HB_11_7,v_HB_11_8,v_HB_11_9,v_HB_11_10,"+\
        "v_HB_10_2,v_HB_10_3,v_HB_10_4,v_HB_10_5,v_HB_10_6,v_HB_10_7,v_HB_10_8,v_HB_10_9,"+\
        "v_HB_9_2,v_HB_9_3,v_HB_9_4,v_HB_9_5,v_HB_9_6,v_HB_9_7,v_HB_9_8,"+\
        "v_HB_8_2,v_HB_8_3,v_HB_8_4,v_HB_8_5,v_HB_8_6,v_HB_8_7,"+\
        "v_HB_7_2,v_HB_7_3,v_HB_7_4,v_HB_7_5,v_HB_7_6,"+\
        "v_HB_6_2,v_HB_6_3,v_HB_6_4,v_HB_6_5,"+\
        "v_HB_5_2,v_HB_5_3,v_HB_5_4,"+\
        "v_HB_4_2,v_HB_4_3,"+\
        "v_HB_3_2,"
        
        # Put together Lennard-Jones and hydrogen bond potentials
        headers_out = headers_LJ+headers_HB

        # Write first line (headers)
        self.fo2.write("PDB,Lig,Chain,Number,"+headers_out+"v_Elec,v_Sol,Torsions,Experimental\n")

        # Write first line (headers)
        self.fo3.write("Name,"+headers_out+"v_Elec,v_Sol,Torsions,Experimental\n")
        
        # Write first line (headers) for Lennard-Jones potentials
        self.fo4.write("PDB,Lig,Chain,Number,"+headers_LJ+"v_Elec,v_Sol,Torsions,Experimental\n")
        
        # Write first line (headers) for hydrogen-bond potentials
        self.fo5.write("PDB,Lig,Chain,Number,"+headers_HB+"v_Elec,v_Sol,Torsions,Experimental\n")
        
        # Write first line (headers) for Lennard-Jones potentials
        self.fo6.write("Name,"+headers_LJ+"v_Elec,v_Sol,Torsions,Experimental\n")
        
        # Write first line (headers) for hydrogen-bond potentials
        self.fo7.write("Name,"+headers_HB+"v_Elec,v_Sol,Torsions,Experimental\n")

        # Instantiating an object of the InterMol() class and assign it to pot
        pot = ad4.InterMol("AD4.1_bound.dat")
        
        # Looping through csv0
        for line in self.csv0:
    
            # Check "FNDWAT" keywork to get ligand data
            if line[0] == "CHKLIG":
            
                # Assign directory for a specific PDB to name_dir
                name_dir = self.dataset_dir+str(line[1])+"/"
        
                # Show where it is reading
                print(name_dir)
        
                # Invoking read_AD4_bound() method
                par_list = pot.read_AD4_bound()
        
                # Invoking read_PDBQT() method
                lig_list = pot.read_PDBQT(name_dir+"lig.pdbqt")
        
                # Invoking read_PDBQT() method
                receptor_list = pot.read_PDBQT(name_dir+"receptor.pdbqt")
        
                # Invoking number_tors
                number_torsions = int(pot.read_torsion(name_dir))
                
                ##########################################################################
                # For van der Waals Interactions
    
                # Invoking intermol_pot_LJ() method
                
                v_LJ_3_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,3,2)

                v_LJ_4_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,4,2)
                v_LJ_4_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,4,3)

                v_LJ_5_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,5,2)
                v_LJ_5_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,5,3)
                v_LJ_5_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,5,4)

                v_LJ_6_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,6,2)
                v_LJ_6_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,6,3)
                v_LJ_6_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,6,4)
                v_LJ_6_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,6,5)
                
                v_LJ_7_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,7,2)
                v_LJ_7_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,7,3)
                v_LJ_7_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,7,4)
                v_LJ_7_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,7,5)
                v_LJ_7_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,7,6)
      
                v_LJ_8_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,8,2)
                v_LJ_8_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,8,3)
                v_LJ_8_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,8,4)
                v_LJ_8_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,8,5)
                v_LJ_8_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,8,6)
                v_LJ_8_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,8,7)
                
                v_LJ_9_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,9,2)
                v_LJ_9_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,9,3)
                v_LJ_9_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,9,4)
                v_LJ_9_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,9,5)
                v_LJ_9_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,9,6)
                v_LJ_9_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,9,7)
                v_LJ_9_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,9,8)
 
                v_LJ_10_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,10,2)
                v_LJ_10_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,10,3)
                v_LJ_10_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,10,4)
                v_LJ_10_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,10,5)
                v_LJ_10_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,10,6)
                v_LJ_10_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,10,7)
                v_LJ_10_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,10,8)
                v_LJ_10_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,10,9)
                
                v_LJ_11_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,11,2)
                v_LJ_11_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,11,3)
                v_LJ_11_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,11,4)
                v_LJ_11_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,11,5)
                v_LJ_11_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,11,6)
                v_LJ_11_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,11,7)
                v_LJ_11_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,11,8)
                v_LJ_11_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,11,9)
                v_LJ_11_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,11,10)
               
                v_LJ_12_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,12,2)
                v_LJ_12_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,12,3)
                v_LJ_12_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,12,4)
                v_LJ_12_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,12,5)
                v_LJ_12_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,12,6)
                v_LJ_12_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,12,7)
                v_LJ_12_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,12,8)
                v_LJ_12_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,12,9)
                v_LJ_12_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,12,10)
                v_LJ_12_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,12,11)
                
                v_LJ_13_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,13,2)
                v_LJ_13_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,13,3)
                v_LJ_13_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,13,4)
                v_LJ_13_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,13,5)
                v_LJ_13_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,13,6)
                v_LJ_13_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,13,7)
                v_LJ_13_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,13,8)
                v_LJ_13_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,13,9)
                v_LJ_13_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,13,10)
                v_LJ_13_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,13,11)
                v_LJ_13_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,13,12)
                
                v_LJ_14_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,14,2)
                v_LJ_14_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,14,3)
                v_LJ_14_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,14,4)
                v_LJ_14_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,14,5)
                v_LJ_14_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,14,6)
                v_LJ_14_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,14,7)
                v_LJ_14_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,14,8)
                v_LJ_14_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,14,9)
                v_LJ_14_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,14,10)
                v_LJ_14_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,14,11)
                v_LJ_14_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,14,12)
                v_LJ_14_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,14,13)
                
                v_LJ_15_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,15,2)
                v_LJ_15_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,15,3)
                v_LJ_15_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,15,4)
                v_LJ_15_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,15,5)
                v_LJ_15_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,15,6)
                v_LJ_15_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,15,7)
                v_LJ_15_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,15,8)
                v_LJ_15_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,15,9)
                v_LJ_15_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,15,10)
                v_LJ_15_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,15,11)
                v_LJ_15_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,15,12)
                v_LJ_15_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,15,13)
                v_LJ_15_14 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,15,14)
       
                v_LJ_16_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,16,2)
                v_LJ_16_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,16,3)
                v_LJ_16_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,16,4)
                v_LJ_16_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,16,5)
                v_LJ_16_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,16,6)
                v_LJ_16_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,16,7)
                v_LJ_16_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,16,8)
                v_LJ_16_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,16,9)
                v_LJ_16_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,16,10)
                v_LJ_16_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,16,11)
                v_LJ_16_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,16,12)
                v_LJ_16_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,16,13)
                v_LJ_16_14 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,16,14)
                v_LJ_16_15 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,16,15) 
                
                v_LJ_17_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,17,2)
                v_LJ_17_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,17,3)
                v_LJ_17_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,17,4)
                v_LJ_17_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,17,5)
                v_LJ_17_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,17,6)
                v_LJ_17_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,17,7)
                v_LJ_17_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,17,8)
                v_LJ_17_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,17,9)
                v_LJ_17_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,17,10)
                v_LJ_17_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,17,11)
                v_LJ_17_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,17,12)
                v_LJ_17_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,17,13)
                v_LJ_17_14 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,17,14)
                v_LJ_17_15 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,17,15)
                v_LJ_17_16 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,17,16)
                
                v_LJ_18_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,18,2)
                v_LJ_18_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,18,3)
                v_LJ_18_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,18,4)
                v_LJ_18_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,18,5)
                v_LJ_18_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,18,6)
                v_LJ_18_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,18,7)
                v_LJ_18_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,18,8)
                v_LJ_18_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,18,9)
                v_LJ_18_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,18,10)
                v_LJ_18_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,18,11)
                v_LJ_18_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,18,12)
                v_LJ_18_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,18,13)
                v_LJ_18_14 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,18,14)
                v_LJ_18_15 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,18,15) 
                v_LJ_18_16 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,18,16) 
                v_LJ_18_17 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,18,17) 
                
                v_LJ_19_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,19,2)
                v_LJ_19_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,19,3)
                v_LJ_19_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,19,4)
                v_LJ_19_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,19,5)
                v_LJ_19_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,19,6)
                v_LJ_19_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,19,7)
                v_LJ_19_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,19,8)
                v_LJ_19_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,19,9)
                v_LJ_19_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,19,10)
                v_LJ_19_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,19,11)
                v_LJ_19_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,19,12)
                v_LJ_19_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,19,13)
                v_LJ_19_14 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,19,14)
                v_LJ_19_15 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,19,15) 
                v_LJ_19_16 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,19,16) 
                v_LJ_19_17 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,19,17) 
                v_LJ_19_18 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,19,18) 
                
                v_LJ_20_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,20,2)
                v_LJ_20_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,20,3)
                v_LJ_20_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,20,4)
                v_LJ_20_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,20,5)
                v_LJ_20_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,20,6)
                v_LJ_20_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,20,7)
                v_LJ_20_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,20,8)
                v_LJ_20_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,20,9)
                v_LJ_20_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,20,10)
                v_LJ_20_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,20,11)
                v_LJ_20_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,20,12)
                v_LJ_20_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,20,13)
                v_LJ_20_14 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,20,14)
                v_LJ_20_15 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,20,15) 
                v_LJ_20_16 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,20,16) 
                v_LJ_20_17 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,20,17) 
                v_LJ_20_18 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,20,18) 
                v_LJ_20_19 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,20,19) 
                
                v_LJ_21_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,2)
                v_LJ_21_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,3)
                v_LJ_21_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,4)
                v_LJ_21_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,5)
                v_LJ_21_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,6)
                v_LJ_21_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,7)
                v_LJ_21_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,8)
                v_LJ_21_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,9)
                v_LJ_21_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,10)
                v_LJ_21_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,11)
                v_LJ_21_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,12)
                v_LJ_21_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,13)
                v_LJ_21_14 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,14)
                v_LJ_21_15 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,15) 
                v_LJ_21_16 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,16) 
                v_LJ_21_17 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,17) 
                v_LJ_21_18 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,18) 
                v_LJ_21_19 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,19) 
                v_LJ_21_20 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,21,20)
                
                v_LJ_22_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,2)
                v_LJ_22_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,3)
                v_LJ_22_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,4)
                v_LJ_22_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,5)
                v_LJ_22_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,6)
                v_LJ_22_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,7)
                v_LJ_22_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,8)
                v_LJ_22_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,9)
                v_LJ_22_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,10)
                v_LJ_22_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,11)
                v_LJ_22_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,12)
                v_LJ_22_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,13)
                v_LJ_22_14 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,14)
                v_LJ_22_15 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,15) 
                v_LJ_22_16 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,16) 
                v_LJ_22_17 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,17) 
                v_LJ_22_18 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,18) 
                v_LJ_22_19 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,19) 
                v_LJ_22_20 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,20)
                v_LJ_22_21 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,22,21)
                
                v_LJ_23_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,2)
                v_LJ_23_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,3)
                v_LJ_23_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,4)
                v_LJ_23_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,5)
                v_LJ_23_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,6)
                v_LJ_23_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,7)
                v_LJ_23_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,8)
                v_LJ_23_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,9)
                v_LJ_23_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,10)
                v_LJ_23_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,11)
                v_LJ_23_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,12)
                v_LJ_23_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,13)
                v_LJ_23_14 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,14)
                v_LJ_23_15 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,15) 
                v_LJ_23_16 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,16) 
                v_LJ_23_17 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,17) 
                v_LJ_23_18 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,18) 
                v_LJ_23_19 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,19) 
                v_LJ_23_20 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,20)
                v_LJ_23_21 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,21)
                v_LJ_23_22 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,23,22)
                
                v_LJ_24_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,2)
                v_LJ_24_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,3)
                v_LJ_24_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,4)
                v_LJ_24_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,5)
                v_LJ_24_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,6)
                v_LJ_24_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,7)
                v_LJ_24_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,8)
                v_LJ_24_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,9)
                v_LJ_24_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,10)
                v_LJ_24_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,11)
                v_LJ_24_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,12)
                v_LJ_24_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,13)
                v_LJ_24_14 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,14)
                v_LJ_24_15 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,15) 
                v_LJ_24_16 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,16) 
                v_LJ_24_17 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,17) 
                v_LJ_24_18 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,18) 
                v_LJ_24_19 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,19) 
                v_LJ_24_20 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,20)
                v_LJ_24_21 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,21)
                v_LJ_24_22 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,22)
                v_LJ_24_23 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,24,23)
                
                v_LJ_25_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,2)
                v_LJ_25_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,3)
                v_LJ_25_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,4)
                v_LJ_25_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,5)
                v_LJ_25_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,6)
                v_LJ_25_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,7)
                v_LJ_25_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,8)
                v_LJ_25_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,9)
                v_LJ_25_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,10)
                v_LJ_25_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,11)
                v_LJ_25_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,12)
                v_LJ_25_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,13)
                v_LJ_25_14 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,14)
                v_LJ_25_15 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,15) 
                v_LJ_25_16 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,16) 
                v_LJ_25_17 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,17) 
                v_LJ_25_18 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,18) 
                v_LJ_25_19 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,19) 
                v_LJ_25_20 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,20)
                v_LJ_25_21 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,21)
                v_LJ_25_22 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,22)
                v_LJ_25_23 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,23)
                v_LJ_25_24 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,25,24)
                
                v_LJ_26_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,2)
                v_LJ_26_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,3)
                v_LJ_26_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,4)
                v_LJ_26_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,5)
                v_LJ_26_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,6)
                v_LJ_26_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,7)
                v_LJ_26_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,8)
                v_LJ_26_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,9)
                v_LJ_26_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,10)
                v_LJ_26_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,11)
                v_LJ_26_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,12)
                v_LJ_26_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,13)
                v_LJ_26_14 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,14)
                v_LJ_26_15 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,15) 
                v_LJ_26_16 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,16) 
                v_LJ_26_17 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,17) 
                v_LJ_26_18 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,18) 
                v_LJ_26_19 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,19) 
                v_LJ_26_20 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,20)
                v_LJ_26_21 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,21)
                v_LJ_26_22 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,22)
                v_LJ_26_23 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,23)
                v_LJ_26_24 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,24)
                v_LJ_26_25 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,26,25)
                
                v_LJ_27_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,2)
                v_LJ_27_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,3)
                v_LJ_27_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,4)
                v_LJ_27_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,5)
                v_LJ_27_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,6)
                v_LJ_27_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,7)
                v_LJ_27_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,8)
                v_LJ_27_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,9)
                v_LJ_27_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,10)
                v_LJ_27_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,11)
                v_LJ_27_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,12)
                v_LJ_27_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,13)
                v_LJ_27_14 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,14)
                v_LJ_27_15 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,15) 
                v_LJ_27_16 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,16) 
                v_LJ_27_17 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,17) 
                v_LJ_27_18 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,18) 
                v_LJ_27_19 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,19) 
                v_LJ_27_20 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,20)
                v_LJ_27_21 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,21)
                v_LJ_27_22 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,22)
                v_LJ_27_23 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,23)
                v_LJ_27_24 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,24)
                v_LJ_27_25 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,25)
                v_LJ_27_26 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,27,26)
                
                v_LJ_28_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,2)
                v_LJ_28_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,3)
                v_LJ_28_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,4)
                v_LJ_28_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,5)
                v_LJ_28_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,6)
                v_LJ_28_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,7)
                v_LJ_28_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,8)
                v_LJ_28_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,9)
                v_LJ_28_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,10)
                v_LJ_28_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,11)
                v_LJ_28_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,12)
                v_LJ_28_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,13)
                v_LJ_28_14 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,14)
                v_LJ_28_15 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,15) 
                v_LJ_28_16 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,16) 
                v_LJ_28_17 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,17) 
                v_LJ_28_18 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,18) 
                v_LJ_28_19 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,19) 
                v_LJ_28_20 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,20)
                v_LJ_28_21 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,21)
                v_LJ_28_22 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,22)
                v_LJ_28_23 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,23)
                v_LJ_28_24 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,24)
                v_LJ_28_25 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,25)
                v_LJ_28_26 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,26)
                v_LJ_28_27 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,28,27)
                
                v_LJ_29_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,2)
                v_LJ_29_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,3)
                v_LJ_29_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,4)
                v_LJ_29_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,5)
                v_LJ_29_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,6)
                v_LJ_29_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,7)
                v_LJ_29_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,8)
                v_LJ_29_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,9)
                v_LJ_29_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,10)
                v_LJ_29_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,11)
                v_LJ_29_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,12)
                v_LJ_29_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,13)
                v_LJ_29_14 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,14)
                v_LJ_29_15 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,15) 
                v_LJ_29_16 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,16) 
                v_LJ_29_17 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,17) 
                v_LJ_29_18 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,18) 
                v_LJ_29_19 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,19) 
                v_LJ_29_20 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,20)
                v_LJ_29_21 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,21)
                v_LJ_29_22 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,22)
                v_LJ_29_23 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,23)
                v_LJ_29_24 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,24)
                v_LJ_29_25 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,25)
                v_LJ_29_26 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,26)
                v_LJ_29_27 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,27)
                v_LJ_29_28 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,29,28)
                
                v_LJ_30_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,2)
                v_LJ_30_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,3)
                v_LJ_30_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,4)
                v_LJ_30_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,5)
                v_LJ_30_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,6)
                v_LJ_30_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,7)
                v_LJ_30_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,8)
                v_LJ_30_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,9)
                v_LJ_30_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,10)
                v_LJ_30_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,11)
                v_LJ_30_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,12)
                v_LJ_30_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,13)
                v_LJ_30_14 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,14)
                v_LJ_30_15 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,15) 
                v_LJ_30_16 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,16) 
                v_LJ_30_17 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,17) 
                v_LJ_30_18 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,18) 
                v_LJ_30_19 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,19) 
                v_LJ_30_20 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,20)
                v_LJ_30_21 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,21)
                v_LJ_30_22 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,22)
                v_LJ_30_23 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,23)
                v_LJ_30_24 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,24)
                v_LJ_30_25 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,25)
                v_LJ_30_26 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,26)
                v_LJ_30_27 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,27)
                v_LJ_30_28 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,28)
                v_LJ_30_29 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,30,29)
                
                v_LJ_31_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,2)
                v_LJ_31_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,3)
                v_LJ_31_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,4)
                v_LJ_31_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,5)
                v_LJ_31_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,6)
                v_LJ_31_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,7)
                v_LJ_31_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,8)
                v_LJ_31_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,9)
                v_LJ_31_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,10)
                v_LJ_31_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,11)
                v_LJ_31_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,12)
                v_LJ_31_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,13)
                v_LJ_31_14 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,14)
                v_LJ_31_15 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,15) 
                v_LJ_31_16 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,16) 
                v_LJ_31_17 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,17) 
                v_LJ_31_18 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,18) 
                v_LJ_31_19 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,19) 
                v_LJ_31_20 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,20)
                v_LJ_31_21 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,21)
                v_LJ_31_22 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,22)
                v_LJ_31_23 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,23)
                v_LJ_31_24 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,24)
                v_LJ_31_25 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,25)
                v_LJ_31_26 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,26)
                v_LJ_31_27 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,27)
                v_LJ_31_28 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,28)
                v_LJ_31_29 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,29)
                v_LJ_31_30 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,31,30)
                
                v_LJ_32_2 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,2)
                v_LJ_32_3 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,3)
                v_LJ_32_4 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,4)
                v_LJ_32_5 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,5)
                v_LJ_32_6 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,6)
                v_LJ_32_7 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,7)
                v_LJ_32_8 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,8)
                v_LJ_32_9 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,9)
                v_LJ_32_10 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,10)
                v_LJ_32_11 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,11)
                v_LJ_32_12 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,12)
                v_LJ_32_13 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,13)
                v_LJ_32_14 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,14)
                v_LJ_32_15 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,15) 
                v_LJ_32_16 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,16) 
                v_LJ_32_17 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,17) 
                v_LJ_32_18 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,18) 
                v_LJ_32_19 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,19) 
                v_LJ_32_20 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,20)
                v_LJ_32_21 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,21)
                v_LJ_32_22 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,22)
                v_LJ_32_23 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,23)
                v_LJ_32_24 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,24)
                v_LJ_32_25 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,25)
                v_LJ_32_26 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,26)
                v_LJ_32_27 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,27)
                v_LJ_32_28 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,28)
                v_LJ_32_29 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,29)
                v_LJ_32_30 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,30)
                v_LJ_32_31 = pot.intermol_pot_LJ(par_list,lig_list,receptor_list,32,31)

        
                ##########################################################################
                # For Hydrogen-bond Interactions
 
                # Invoking intermol_pot_HB() method

                v_HB_3_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,3,2)

                v_HB_4_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,4,2)
                v_HB_4_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,4,3)

                v_HB_5_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,5,2)
                v_HB_5_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,5,3)
                v_HB_5_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,5,4)

                v_HB_6_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,6,2)
                v_HB_6_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,6,3)
                v_HB_6_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,6,4)
                v_HB_6_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,6,5)
                
                v_HB_7_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,7,2)
                v_HB_7_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,7,3)
                v_HB_7_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,7,4)
                v_HB_7_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,7,5)
                v_HB_7_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,7,6)
      
                v_HB_8_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,8,2)
                v_HB_8_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,8,3)
                v_HB_8_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,8,4)
                v_HB_8_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,8,5)
                v_HB_8_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,8,6)
                v_HB_8_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,8,7)
                
                v_HB_9_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,9,2)
                v_HB_9_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,9,3)
                v_HB_9_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,9,4)
                v_HB_9_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,9,5)
                v_HB_9_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,9,6)
                v_HB_9_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,9,7)
                v_HB_9_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,9,8)
 
                v_HB_10_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,10,2)
                v_HB_10_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,10,3)
                v_HB_10_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,10,4)
                v_HB_10_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,10,5)
                v_HB_10_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,10,6)
                v_HB_10_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,10,7)
                v_HB_10_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,10,8)
                v_HB_10_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,10,9)
                
                v_HB_11_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,11,2)
                v_HB_11_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,11,3)
                v_HB_11_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,11,4)
                v_HB_11_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,11,5)
                v_HB_11_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,11,6)
                v_HB_11_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,11,7)
                v_HB_11_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,11,8)
                v_HB_11_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,11,9)
                v_HB_11_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,11,10)
               
                v_HB_12_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,12,2)
                v_HB_12_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,12,3)
                v_HB_12_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,12,4)
                v_HB_12_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,12,5)
                v_HB_12_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,12,6)
                v_HB_12_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,12,7)
                v_HB_12_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,12,8)
                v_HB_12_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,12,9)
                v_HB_12_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,12,10)
                v_HB_12_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,12,11)
                
                v_HB_13_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,13,2)
                v_HB_13_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,13,3)
                v_HB_13_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,13,4)
                v_HB_13_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,13,5)
                v_HB_13_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,13,6)
                v_HB_13_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,13,7)
                v_HB_13_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,13,8)
                v_HB_13_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,13,9)
                v_HB_13_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,13,10)
                v_HB_13_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,13,11)
                v_HB_13_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,13,12)
                
                v_HB_14_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,14,2)
                v_HB_14_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,14,3)
                v_HB_14_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,14,4)
                v_HB_14_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,14,5)
                v_HB_14_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,14,6)
                v_HB_14_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,14,7)
                v_HB_14_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,14,8)
                v_HB_14_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,14,9)
                v_HB_14_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,14,10)
                v_HB_14_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,14,11)
                v_HB_14_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,14,12)
                v_HB_14_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,14,13)
                
                v_HB_15_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,15,2)
                v_HB_15_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,15,3)
                v_HB_15_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,15,4)
                v_HB_15_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,15,5)
                v_HB_15_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,15,6)
                v_HB_15_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,15,7)
                v_HB_15_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,15,8)
                v_HB_15_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,15,9)
                v_HB_15_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,15,10)
                v_HB_15_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,15,11)
                v_HB_15_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,15,12)
                v_HB_15_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,15,13)
                v_HB_15_14 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,15,14)
       
                v_HB_16_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,16,2)
                v_HB_16_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,16,3)
                v_HB_16_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,16,4)
                v_HB_16_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,16,5)
                v_HB_16_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,16,6)
                v_HB_16_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,16,7)
                v_HB_16_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,16,8)
                v_HB_16_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,16,9)
                v_HB_16_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,16,10)
                v_HB_16_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,16,11)
                v_HB_16_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,16,12)
                v_HB_16_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,16,13)
                v_HB_16_14 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,16,14)
                v_HB_16_15 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,16,15) 
                
                v_HB_17_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,17,2)
                v_HB_17_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,17,3)
                v_HB_17_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,17,4)
                v_HB_17_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,17,5)
                v_HB_17_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,17,6)
                v_HB_17_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,17,7)
                v_HB_17_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,17,8)
                v_HB_17_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,17,9)
                v_HB_17_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,17,10)
                v_HB_17_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,17,11)
                v_HB_17_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,17,12)
                v_HB_17_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,17,13)
                v_HB_17_14 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,17,14)
                v_HB_17_15 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,17,15)
                v_HB_17_16 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,17,16)
                
                v_HB_18_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,18,2)
                v_HB_18_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,18,3)
                v_HB_18_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,18,4)
                v_HB_18_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,18,5)
                v_HB_18_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,18,6)
                v_HB_18_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,18,7)
                v_HB_18_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,18,8)
                v_HB_18_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,18,9)
                v_HB_18_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,18,10)
                v_HB_18_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,18,11)
                v_HB_18_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,18,12)
                v_HB_18_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,18,13)
                v_HB_18_14 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,18,14)
                v_HB_18_15 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,18,15) 
                v_HB_18_16 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,18,16) 
                v_HB_18_17 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,18,17) 
                
                v_HB_19_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,19,2)
                v_HB_19_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,19,3)
                v_HB_19_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,19,4)
                v_HB_19_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,19,5)
                v_HB_19_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,19,6)
                v_HB_19_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,19,7)
                v_HB_19_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,19,8)
                v_HB_19_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,19,9)
                v_HB_19_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,19,10)
                v_HB_19_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,19,11)
                v_HB_19_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,19,12)
                v_HB_19_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,19,13)
                v_HB_19_14 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,19,14)
                v_HB_19_15 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,19,15) 
                v_HB_19_16 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,19,16) 
                v_HB_19_17 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,19,17) 
                v_HB_19_18 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,19,18) 
                
                v_HB_20_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,20,2)
                v_HB_20_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,20,3)
                v_HB_20_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,20,4)
                v_HB_20_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,20,5)
                v_HB_20_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,20,6)
                v_HB_20_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,20,7)
                v_HB_20_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,20,8)
                v_HB_20_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,20,9)
                v_HB_20_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,20,10)
                v_HB_20_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,20,11)
                v_HB_20_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,20,12)
                v_HB_20_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,20,13)
                v_HB_20_14 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,20,14)
                v_HB_20_15 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,20,15) 
                v_HB_20_16 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,20,16) 
                v_HB_20_17 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,20,17) 
                v_HB_20_18 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,20,18) 
                v_HB_20_19 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,20,19) 
                
                v_HB_21_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,2)
                v_HB_21_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,3)
                v_HB_21_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,4)
                v_HB_21_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,5)
                v_HB_21_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,6)
                v_HB_21_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,7)
                v_HB_21_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,8)
                v_HB_21_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,9)
                v_HB_21_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,10)
                v_HB_21_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,11)
                v_HB_21_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,12)
                v_HB_21_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,13)
                v_HB_21_14 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,14)
                v_HB_21_15 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,15) 
                v_HB_21_16 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,16) 
                v_HB_21_17 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,17) 
                v_HB_21_18 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,18) 
                v_HB_21_19 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,19) 
                v_HB_21_20 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,21,20)
                
                v_HB_22_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,2)
                v_HB_22_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,3)
                v_HB_22_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,4)
                v_HB_22_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,5)
                v_HB_22_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,6)
                v_HB_22_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,7)
                v_HB_22_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,8)
                v_HB_22_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,9)
                v_HB_22_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,10)
                v_HB_22_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,11)
                v_HB_22_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,12)
                v_HB_22_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,13)
                v_HB_22_14 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,14)
                v_HB_22_15 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,15) 
                v_HB_22_16 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,16) 
                v_HB_22_17 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,17) 
                v_HB_22_18 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,18) 
                v_HB_22_19 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,19) 
                v_HB_22_20 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,20)
                v_HB_22_21 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,22,21)
                
                v_HB_23_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,2)
                v_HB_23_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,3)
                v_HB_23_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,4)
                v_HB_23_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,5)
                v_HB_23_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,6)
                v_HB_23_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,7)
                v_HB_23_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,8)
                v_HB_23_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,9)
                v_HB_23_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,10)
                v_HB_23_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,11)
                v_HB_23_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,12)
                v_HB_23_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,13)
                v_HB_23_14 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,14)
                v_HB_23_15 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,15) 
                v_HB_23_16 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,16) 
                v_HB_23_17 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,17) 
                v_HB_23_18 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,18) 
                v_HB_23_19 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,19) 
                v_HB_23_20 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,20)
                v_HB_23_21 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,21)
                v_HB_23_22 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,23,22)
                
                v_HB_24_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,2)
                v_HB_24_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,3)
                v_HB_24_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,4)
                v_HB_24_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,5)
                v_HB_24_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,6)
                v_HB_24_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,7)
                v_HB_24_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,8)
                v_HB_24_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,9)
                v_HB_24_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,10)
                v_HB_24_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,11)
                v_HB_24_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,12)
                v_HB_24_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,13)
                v_HB_24_14 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,14)
                v_HB_24_15 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,15) 
                v_HB_24_16 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,16) 
                v_HB_24_17 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,17) 
                v_HB_24_18 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,18) 
                v_HB_24_19 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,19) 
                v_HB_24_20 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,20)
                v_HB_24_21 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,21)
                v_HB_24_22 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,22)
                v_HB_24_23 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,24,23)
                
                v_HB_25_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,2)
                v_HB_25_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,3)
                v_HB_25_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,4)
                v_HB_25_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,5)
                v_HB_25_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,6)
                v_HB_25_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,7)
                v_HB_25_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,8)
                v_HB_25_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,9)
                v_HB_25_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,10)
                v_HB_25_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,11)
                v_HB_25_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,12)
                v_HB_25_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,13)
                v_HB_25_14 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,14)
                v_HB_25_15 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,15) 
                v_HB_25_16 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,16) 
                v_HB_25_17 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,17) 
                v_HB_25_18 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,18) 
                v_HB_25_19 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,19) 
                v_HB_25_20 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,20)
                v_HB_25_21 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,21)
                v_HB_25_22 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,22)
                v_HB_25_23 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,23)
                v_HB_25_24 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,25,24)
                
                v_HB_26_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,2)
                v_HB_26_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,3)
                v_HB_26_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,4)
                v_HB_26_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,5)
                v_HB_26_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,6)
                v_HB_26_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,7)
                v_HB_26_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,8)
                v_HB_26_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,9)
                v_HB_26_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,10)
                v_HB_26_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,11)
                v_HB_26_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,12)
                v_HB_26_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,13)
                v_HB_26_14 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,14)
                v_HB_26_15 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,15) 
                v_HB_26_16 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,16) 
                v_HB_26_17 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,17) 
                v_HB_26_18 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,18) 
                v_HB_26_19 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,19) 
                v_HB_26_20 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,20)
                v_HB_26_21 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,21)
                v_HB_26_22 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,22)
                v_HB_26_23 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,23)
                v_HB_26_24 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,24)
                v_HB_26_25 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,26,25)
                
                v_HB_27_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,2)
                v_HB_27_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,3)
                v_HB_27_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,4)
                v_HB_27_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,5)
                v_HB_27_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,6)
                v_HB_27_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,7)
                v_HB_27_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,8)
                v_HB_27_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,9)
                v_HB_27_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,10)
                v_HB_27_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,11)
                v_HB_27_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,12)
                v_HB_27_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,13)
                v_HB_27_14 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,14)
                v_HB_27_15 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,15) 
                v_HB_27_16 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,16) 
                v_HB_27_17 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,17) 
                v_HB_27_18 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,18) 
                v_HB_27_19 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,19) 
                v_HB_27_20 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,20)
                v_HB_27_21 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,21)
                v_HB_27_22 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,22)
                v_HB_27_23 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,23)
                v_HB_27_24 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,24)
                v_HB_27_25 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,25)
                v_HB_27_26 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,27,26)
                
                v_HB_28_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,2)
                v_HB_28_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,3)
                v_HB_28_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,4)
                v_HB_28_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,5)
                v_HB_28_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,6)
                v_HB_28_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,7)
                v_HB_28_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,8)
                v_HB_28_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,9)
                v_HB_28_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,10)
                v_HB_28_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,11)
                v_HB_28_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,12)
                v_HB_28_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,13)
                v_HB_28_14 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,14)
                v_HB_28_15 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,15) 
                v_HB_28_16 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,16) 
                v_HB_28_17 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,17) 
                v_HB_28_18 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,18) 
                v_HB_28_19 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,19) 
                v_HB_28_20 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,20)
                v_HB_28_21 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,21)
                v_HB_28_22 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,22)
                v_HB_28_23 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,23)
                v_HB_28_24 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,24)
                v_HB_28_25 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,25)
                v_HB_28_26 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,26)
                v_HB_28_27 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,28,27)
                
                v_HB_29_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,2)
                v_HB_29_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,3)
                v_HB_29_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,4)
                v_HB_29_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,5)
                v_HB_29_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,6)
                v_HB_29_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,7)
                v_HB_29_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,8)
                v_HB_29_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,9)
                v_HB_29_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,10)
                v_HB_29_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,11)
                v_HB_29_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,12)
                v_HB_29_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,13)
                v_HB_29_14 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,14)
                v_HB_29_15 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,15) 
                v_HB_29_16 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,16) 
                v_HB_29_17 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,17) 
                v_HB_29_18 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,18) 
                v_HB_29_19 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,19) 
                v_HB_29_20 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,20)
                v_HB_29_21 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,21)
                v_HB_29_22 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,22)
                v_HB_29_23 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,23)
                v_HB_29_24 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,24)
                v_HB_29_25 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,25)
                v_HB_29_26 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,26)
                v_HB_29_27 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,27)
                v_HB_29_28 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,29,28)
                
                v_HB_30_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,2)
                v_HB_30_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,3)
                v_HB_30_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,4)
                v_HB_30_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,5)
                v_HB_30_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,6)
                v_HB_30_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,7)
                v_HB_30_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,8)
                v_HB_30_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,9)
                v_HB_30_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,10)
                v_HB_30_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,11)
                v_HB_30_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,12)
                v_HB_30_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,13)
                v_HB_30_14 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,14)
                v_HB_30_15 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,15) 
                v_HB_30_16 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,16) 
                v_HB_30_17 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,17) 
                v_HB_30_18 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,18) 
                v_HB_30_19 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,19) 
                v_HB_30_20 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,20)
                v_HB_30_21 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,21)
                v_HB_30_22 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,22)
                v_HB_30_23 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,23)
                v_HB_30_24 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,24)
                v_HB_30_25 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,25)
                v_HB_30_26 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,26)
                v_HB_30_27 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,27)
                v_HB_30_28 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,28)
                v_HB_30_29 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,30,29)
                
                v_HB_31_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,2)
                v_HB_31_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,3)
                v_HB_31_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,4)
                v_HB_31_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,5)
                v_HB_31_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,6)
                v_HB_31_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,7)
                v_HB_31_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,8)
                v_HB_31_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,9)
                v_HB_31_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,10)
                v_HB_31_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,11)
                v_HB_31_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,12)
                v_HB_31_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,13)
                v_HB_31_14 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,14)
                v_HB_31_15 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,15) 
                v_HB_31_16 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,16) 
                v_HB_31_17 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,17) 
                v_HB_31_18 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,18) 
                v_HB_31_19 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,19) 
                v_HB_31_20 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,20)
                v_HB_31_21 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,21)
                v_HB_31_22 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,22)
                v_HB_31_23 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,23)
                v_HB_31_24 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,24)
                v_HB_31_25 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,25)
                v_HB_31_26 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,26)
                v_HB_31_27 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,27)
                v_HB_31_28 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,28)
                v_HB_31_29 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,29)
                v_HB_31_30 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,31,30)
                
                v_HB_32_2 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,2)
                v_HB_32_3 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,3)
                v_HB_32_4 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,4)
                v_HB_32_5 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,5)
                v_HB_32_6 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,6)
                v_HB_32_7 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,7)
                v_HB_32_8 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,8)
                v_HB_32_9 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,9)
                v_HB_32_10 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,10)
                v_HB_32_11 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,11)
                v_HB_32_12 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,12)
                v_HB_32_13 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,13)
                v_HB_32_14 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,14)
                v_HB_32_15 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,15) 
                v_HB_32_16 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,16) 
                v_HB_32_17 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,17) 
                v_HB_32_18 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,18) 
                v_HB_32_19 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,19) 
                v_HB_32_20 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,20)
                v_HB_32_21 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,21)
                v_HB_32_22 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,22)
                v_HB_32_23 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,23)
                v_HB_32_24 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,24)
                v_HB_32_25 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,25)
                v_HB_32_26 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,26)
                v_HB_32_27 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,27)
                v_HB_32_28 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,28)
                v_HB_32_29 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,29)
                v_HB_32_30 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,30)
                v_HB_32_31 = pot.intermol_pot_HB(par_list,lig_list,receptor_list,32,31)

        
                ##########################################################################
                # For Electrostactic Potential

                # Invoking intermol_pot_Sol() method
                v_Elec = pot.intermol_electro(lig_list,receptor_list)
        
                # Show result
                #print("V_Elec(r) = %10.3f"%v_Elec,"Kcal/mol") 
        
                ##########################################################################
                # For Solvatation
            
                # Invoking intermol_pot_Sol() method
                v_Sol = pot.intermol_pot_Sol(par_list,lig_list,receptor_list,12,6)
                        
                # Show result
                #print("V_Sol(r) = %10.3f"%v_Sol,"Kcal/mol") 
        
                # Take care of length 4
                aux0 = str(line[4])
                aux = aux0.replace(" ","")

                ##########################################################################

                # Get experimental affinity considering different type of binding affinity
                if self.binding_type == "deltag":
                    exp_aff = float(line[5])
                else:
                    exp_aff = -9+np.log10(float(line[5]))
                
                aux_line_LJ = ""+\
                ","+str(v_LJ_32_2)+","+str(v_LJ_32_3)+","+str(v_LJ_32_4)+","+str(v_LJ_32_5)+\
                ","+str(v_LJ_32_6)+","+str(v_LJ_32_7)+","+str(v_LJ_32_8)+","+str(v_LJ_32_9)+\
                ","+str(v_LJ_32_10)+","+str(v_LJ_32_11)+","+str(v_LJ_32_12)+","+str(v_LJ_32_13)+\
                ","+str(v_LJ_32_14)+","+str(v_LJ_32_15)+","+str(v_LJ_32_16)+","+str(v_LJ_32_17)+\
                ","+str(v_LJ_32_18)+","+str(v_LJ_32_19)+","+str(v_LJ_32_20)+","+str(v_LJ_32_21)+\
                ","+str(v_LJ_32_22)+","+str(v_LJ_32_23)+","+str(v_LJ_32_24)+","+str(v_LJ_32_25)+\
                ","+str(v_LJ_32_26)+","+str(v_LJ_32_27)+","+str(v_LJ_32_28)+","+str(v_LJ_32_29)+\
                ","+str(v_LJ_32_30)+","+str(v_LJ_32_31)+\
                ","+str(v_LJ_31_2)+","+str(v_LJ_31_3)+","+str(v_LJ_31_4)+","+str(v_LJ_31_5)+\
                ","+str(v_LJ_31_6)+","+str(v_LJ_31_7)+","+str(v_LJ_31_8)+","+str(v_LJ_31_9)+\
                ","+str(v_LJ_31_10)+","+str(v_LJ_31_11)+","+str(v_LJ_31_12)+","+str(v_LJ_31_13)+\
                ","+str(v_LJ_31_14)+","+str(v_LJ_31_15)+","+str(v_LJ_31_16)+","+str(v_LJ_31_17)+\
                ","+str(v_LJ_31_18)+","+str(v_LJ_31_19)+","+str(v_LJ_31_20)+","+str(v_LJ_31_21)+\
                ","+str(v_LJ_31_22)+","+str(v_LJ_31_23)+","+str(v_LJ_31_24)+","+str(v_LJ_31_25)+\
                ","+str(v_LJ_31_26)+","+str(v_LJ_31_27)+","+str(v_LJ_31_28)+","+str(v_LJ_31_29)+\
                ","+str(v_LJ_31_30)+\
                ","+str(v_LJ_30_2)+","+str(v_LJ_30_3)+","+str(v_LJ_30_4)+","+str(v_LJ_30_5)+\
                ","+str(v_LJ_30_6)+","+str(v_LJ_30_7)+","+str(v_LJ_30_8)+","+str(v_LJ_30_9)+\
                ","+str(v_LJ_30_10)+","+str(v_LJ_30_11)+","+str(v_LJ_30_12)+","+str(v_LJ_30_13)+\
                ","+str(v_LJ_30_14)+","+str(v_LJ_30_15)+","+str(v_LJ_30_16)+","+str(v_LJ_30_17)+\
                ","+str(v_LJ_30_18)+","+str(v_LJ_30_19)+","+str(v_LJ_30_20)+","+str(v_LJ_30_21)+\
                ","+str(v_LJ_30_22)+","+str(v_LJ_30_23)+","+str(v_LJ_30_24)+","+str(v_LJ_30_25)+\
                ","+str(v_LJ_30_26)+","+str(v_LJ_30_27)+","+str(v_LJ_30_28)+","+str(v_LJ_30_29)+\
                ","+str(v_LJ_29_2)+","+str(v_LJ_29_3)+","+str(v_LJ_29_4)+","+str(v_LJ_29_5)+\
                ","+str(v_LJ_29_6)+","+str(v_LJ_29_7)+","+str(v_LJ_29_8)+","+str(v_LJ_29_9)+\
                ","+str(v_LJ_29_10)+","+str(v_LJ_29_11)+","+str(v_LJ_29_12)+","+str(v_LJ_29_13)+\
                ","+str(v_LJ_29_14)+","+str(v_LJ_29_15)+","+str(v_LJ_29_16)+","+str(v_LJ_29_17)+\
                ","+str(v_LJ_29_18)+","+str(v_LJ_29_19)+","+str(v_LJ_29_20)+","+str(v_LJ_29_21)+\
                ","+str(v_LJ_29_22)+","+str(v_LJ_29_23)+","+str(v_LJ_29_24)+","+str(v_LJ_29_25)+\
                ","+str(v_LJ_29_26)+","+str(v_LJ_29_27)+","+str(v_LJ_29_28)+\
                ","+str(v_LJ_28_2)+","+str(v_LJ_28_3)+","+str(v_LJ_28_4)+","+str(v_LJ_28_5)+\
                ","+str(v_LJ_28_6)+","+str(v_LJ_28_7)+","+str(v_LJ_28_8)+","+str(v_LJ_28_9)+\
                ","+str(v_LJ_28_10)+","+str(v_LJ_28_11)+","+str(v_LJ_28_12)+","+str(v_LJ_28_13)+\
                ","+str(v_LJ_28_14)+","+str(v_LJ_28_15)+","+str(v_LJ_28_16)+","+str(v_LJ_28_17)+\
                ","+str(v_LJ_28_18)+","+str(v_LJ_28_19)+","+str(v_LJ_28_20)+","+str(v_LJ_28_21)+\
                ","+str(v_LJ_28_22)+","+str(v_LJ_28_23)+","+str(v_LJ_28_24)+","+str(v_LJ_28_25)+\
                ","+str(v_LJ_28_26)+","+str(v_LJ_28_27)+\
                ","+str(v_LJ_27_2)+","+str(v_LJ_27_3)+","+str(v_LJ_27_4)+","+str(v_LJ_27_5)+\
                ","+str(v_LJ_27_6)+","+str(v_LJ_27_7)+","+str(v_LJ_27_8)+","+str(v_LJ_27_9)+\
                ","+str(v_LJ_27_10)+","+str(v_LJ_27_11)+","+str(v_LJ_27_12)+","+str(v_LJ_27_13)+\
                ","+str(v_LJ_27_14)+","+str(v_LJ_27_15)+","+str(v_LJ_27_16)+","+str(v_LJ_27_17)+\
                ","+str(v_LJ_27_18)+","+str(v_LJ_27_19)+","+str(v_LJ_27_20)+","+str(v_LJ_27_21)+\
                ","+str(v_LJ_27_22)+","+str(v_LJ_27_23)+","+str(v_LJ_27_24)+","+str(v_LJ_27_25)+\
                ","+str(v_LJ_27_26)+\
                ","+str(v_LJ_26_2)+","+str(v_LJ_26_3)+","+str(v_LJ_26_4)+","+str(v_LJ_26_5)+\
                ","+str(v_LJ_26_6)+","+str(v_LJ_26_7)+","+str(v_LJ_26_8)+","+str(v_LJ_26_9)+\
                ","+str(v_LJ_26_10)+","+str(v_LJ_26_11)+","+str(v_LJ_26_12)+","+str(v_LJ_26_13)+\
                ","+str(v_LJ_26_14)+","+str(v_LJ_26_15)+","+str(v_LJ_26_16)+","+str(v_LJ_26_17)+\
                ","+str(v_LJ_26_18)+","+str(v_LJ_26_19)+","+str(v_LJ_26_20)+","+str(v_LJ_26_21)+\
                ","+str(v_LJ_26_22)+","+str(v_LJ_26_23)+","+str(v_LJ_26_24)+","+str(v_LJ_26_25)+\
                ","+str(v_LJ_25_2)+","+str(v_LJ_25_3)+","+str(v_LJ_25_4)+","+str(v_LJ_25_5)+\
                ","+str(v_LJ_25_6)+","+str(v_LJ_25_7)+","+str(v_LJ_25_8)+","+str(v_LJ_25_9)+\
                ","+str(v_LJ_25_10)+","+str(v_LJ_25_11)+","+str(v_LJ_25_12)+","+str(v_LJ_25_13)+\
                ","+str(v_LJ_25_14)+","+str(v_LJ_25_15)+","+str(v_LJ_25_16)+","+str(v_LJ_25_17)+\
                ","+str(v_LJ_25_18)+","+str(v_LJ_25_19)+","+str(v_LJ_25_20)+","+str(v_LJ_25_21)+\
                ","+str(v_LJ_25_22)+","+str(v_LJ_25_23)+","+str(v_LJ_25_24)+\
                ","+str(v_LJ_24_2)+","+str(v_LJ_24_3)+","+str(v_LJ_24_4)+","+str(v_LJ_24_5)+\
                ","+str(v_LJ_24_6)+","+str(v_LJ_24_7)+","+str(v_LJ_24_8)+","+str(v_LJ_24_9)+\
                ","+str(v_LJ_24_10)+","+str(v_LJ_24_11)+","+str(v_LJ_24_12)+","+str(v_LJ_24_13)+\
                ","+str(v_LJ_24_14)+","+str(v_LJ_24_15)+","+str(v_LJ_24_16)+","+str(v_LJ_24_17)+\
                ","+str(v_LJ_24_18)+","+str(v_LJ_24_19)+","+str(v_LJ_24_20)+","+str(v_LJ_24_21)+\
                ","+str(v_LJ_24_22)+","+str(v_LJ_24_23)+\
                ","+str(v_LJ_23_2)+","+str(v_LJ_23_3)+","+str(v_LJ_23_4)+","+str(v_LJ_23_5)+\
                ","+str(v_LJ_23_6)+","+str(v_LJ_23_7)+","+str(v_LJ_23_8)+","+str(v_LJ_23_9)+\
                ","+str(v_LJ_23_10)+","+str(v_LJ_23_11)+","+str(v_LJ_23_12)+","+str(v_LJ_23_13)+\
                ","+str(v_LJ_23_14)+","+str(v_LJ_23_15)+","+str(v_LJ_23_16)+","+str(v_LJ_23_17)+\
                ","+str(v_LJ_23_18)+","+str(v_LJ_23_19)+","+str(v_LJ_23_20)+","+str(v_LJ_23_21)+\
                ","+str(v_LJ_23_22)+\
                ","+str(v_LJ_22_2)+","+str(v_LJ_22_3)+","+str(v_LJ_22_4)+","+str(v_LJ_22_5)+\
                ","+str(v_LJ_22_6)+","+str(v_LJ_22_7)+","+str(v_LJ_22_8)+","+str(v_LJ_22_9)+\
                ","+str(v_LJ_22_10)+","+str(v_LJ_22_11)+","+str(v_LJ_22_12)+","+str(v_LJ_22_13)+\
                ","+str(v_LJ_22_14)+","+str(v_LJ_22_15)+","+str(v_LJ_22_16)+","+str(v_LJ_22_17)+\
                ","+str(v_LJ_22_18)+","+str(v_LJ_22_19)+","+str(v_LJ_22_20)+","+str(v_LJ_22_21)+\
                ","+str(v_LJ_21_2)+","+str(v_LJ_21_3)+","+str(v_LJ_21_4)+","+str(v_LJ_21_5)+\
                ","+str(v_LJ_21_6)+","+str(v_LJ_21_7)+","+str(v_LJ_21_8)+","+str(v_LJ_21_9)+\
                ","+str(v_LJ_21_10)+","+str(v_LJ_21_11)+","+str(v_LJ_21_12)+","+str(v_LJ_21_13)+\
                ","+str(v_LJ_21_14)+","+str(v_LJ_21_15)+","+str(v_LJ_21_16)+","+str(v_LJ_21_17)+\
                ","+str(v_LJ_21_18)+","+str(v_LJ_21_19)+","+str(v_LJ_21_20)+\
                ","+str(v_LJ_20_2)+","+str(v_LJ_20_3)+","+str(v_LJ_20_4)+","+str(v_LJ_20_5)+\
                ","+str(v_LJ_20_6)+","+str(v_LJ_20_7)+","+str(v_LJ_20_8)+","+str(v_LJ_20_9)+\
                ","+str(v_LJ_20_10)+","+str(v_LJ_20_11)+","+str(v_LJ_20_12)+","+str(v_LJ_20_13)+\
                ","+str(v_LJ_20_14)+","+str(v_LJ_20_15)+","+str(v_LJ_20_16)+","+str(v_LJ_20_17)+\
                ","+str(v_LJ_20_18)+","+str(v_LJ_20_19)+\
                ","+str(v_LJ_19_2)+","+str(v_LJ_19_3)+","+str(v_LJ_19_4)+","+str(v_LJ_19_5)+\
                ","+str(v_LJ_19_6)+","+str(v_LJ_19_7)+","+str(v_LJ_19_8)+","+str(v_LJ_19_9)+\
                ","+str(v_LJ_19_10)+","+str(v_LJ_19_11)+","+str(v_LJ_19_12)+","+str(v_LJ_19_13)+\
                ","+str(v_LJ_19_14)+","+str(v_LJ_19_15)+","+str(v_LJ_19_16)+","+str(v_LJ_19_17)+\
                ","+str(v_LJ_19_18)+\
                ","+str(v_LJ_18_2)+","+str(v_LJ_18_3)+","+str(v_LJ_18_4)+","+str(v_LJ_18_5)+\
                ","+str(v_LJ_18_6)+","+str(v_LJ_18_7)+","+str(v_LJ_18_8)+","+str(v_LJ_18_9)+\
                ","+str(v_LJ_18_10)+","+str(v_LJ_18_11)+","+str(v_LJ_18_12)+","+str(v_LJ_18_13)+\
                ","+str(v_LJ_18_14)+","+str(v_LJ_18_15)+","+str(v_LJ_18_16)+","+str(v_LJ_18_17)+\
                ","+str(v_LJ_17_2)+","+str(v_LJ_17_3)+","+str(v_LJ_17_4)+","+str(v_LJ_17_5)+\
                ","+str(v_LJ_17_6)+","+str(v_LJ_17_7)+","+str(v_LJ_17_8)+","+str(v_LJ_17_9)+\
                ","+str(v_LJ_17_10)+","+str(v_LJ_17_11)+","+str(v_LJ_17_12)+","+str(v_LJ_17_13)+\
                ","+str(v_LJ_17_14)+","+str(v_LJ_17_15)+","+str(v_LJ_17_16)+\
                ","+str(v_LJ_16_2)+","+str(v_LJ_16_3)+","+str(v_LJ_16_4)+","+str(v_LJ_16_5)+\
                ","+str(v_LJ_16_6)+","+str(v_LJ_16_7)+","+str(v_LJ_16_8)+","+str(v_LJ_16_9)+\
                ","+str(v_LJ_16_10)+","+str(v_LJ_16_11)+","+str(v_LJ_16_12)+","+str(v_LJ_16_13)+\
                ","+str(v_LJ_16_14)+","+str(v_LJ_16_15)+\
                ","+str(v_LJ_15_2)+","+str(v_LJ_15_3)+","+str(v_LJ_15_4)+","+str(v_LJ_15_5)+\
                ","+str(v_LJ_15_6)+","+str(v_LJ_15_7)+","+str(v_LJ_15_8)+","+str(v_LJ_15_9)+\
                ","+str(v_LJ_15_10)+","+str(v_LJ_15_11)+","+str(v_LJ_15_12)+","+str(v_LJ_15_13)+\
                ","+str(v_LJ_15_14)+\
                ","+str(v_LJ_14_2)+","+str(v_LJ_14_3)+","+str(v_LJ_14_4)+","+str(v_LJ_14_5)+\
                ","+str(v_LJ_14_6)+","+str(v_LJ_14_7)+","+str(v_LJ_14_8)+","+str(v_LJ_14_9)+\
                ","+str(v_LJ_14_10)+","+str(v_LJ_14_11)+","+str(v_LJ_14_12)+","+str(v_LJ_14_13)+\
                ","+str(v_LJ_13_2)+","+str(v_LJ_13_3)+","+str(v_LJ_13_4)+","+str(v_LJ_13_5)+\
                ","+str(v_LJ_13_6)+","+str(v_LJ_13_7)+","+str(v_LJ_13_8)+","+str(v_LJ_13_9)+\
                ","+str(v_LJ_13_10)+","+str(v_LJ_13_11)+","+str(v_LJ_13_12)+\
                ","+str(v_LJ_12_2)+","+str(v_LJ_12_3)+","+str(v_LJ_12_4)+","+str(v_LJ_12_5)+\
                ","+str(v_LJ_12_6)+","+str(v_LJ_12_7)+","+str(v_LJ_12_8)+","+str(v_LJ_12_9)+\
                ","+str(v_LJ_12_10)+","+str(v_LJ_12_11)+\
                ","+str(v_LJ_11_2)+","+str(v_LJ_11_3)+","+str(v_LJ_11_4)+","+str(v_LJ_11_5)+\
                ","+str(v_LJ_11_6)+","+str(v_LJ_11_7)+","+str(v_LJ_11_8)+","+str(v_LJ_11_9)+\
                ","+str(v_LJ_11_10)+\
                ","+str(v_LJ_10_2)+","+str(v_LJ_10_3)+","+str(v_LJ_10_4)+","+str(v_LJ_10_5)+\
                ","+str(v_LJ_10_6)+","+str(v_LJ_10_7)+","+str(v_LJ_10_8)+","+str(v_LJ_10_9)+\
                ","+str(v_LJ_9_2)+","+str(v_LJ_9_3)+","+str(v_LJ_9_4)+","+str(v_LJ_9_5)+\
                ","+str(v_LJ_9_6)+","+str(v_LJ_9_7)+","+str(v_LJ_9_8)+\
                ","+str(v_LJ_8_2)+","+str(v_LJ_8_3)+","+str(v_LJ_8_4)+","+str(v_LJ_8_5)+\
                ","+str(v_LJ_8_6)+","+str(v_LJ_8_7)+\
                ","+str(v_LJ_7_2)+","+str(v_LJ_7_3)+","+str(v_LJ_7_4)+","+str(v_LJ_7_5)+\
                ","+str(v_LJ_7_6)+\
                ","+str(v_LJ_6_2)+","+str(v_LJ_6_3)+","+str(v_LJ_6_4)+","+str(v_LJ_6_5)+\
                ","+str(v_LJ_5_2)+","+str(v_LJ_5_3)+","+str(v_LJ_5_4)+\
                ","+str(v_LJ_4_2)+","+str(v_LJ_4_3)+\
                ","+str(v_LJ_3_2)
                
                aux_line_HB = ""+\
                ","+str(v_HB_32_2)+","+str(v_HB_32_3)+","+str(v_HB_32_4)+","+str(v_HB_32_5)+\
                ","+str(v_HB_32_6)+","+str(v_HB_32_7)+","+str(v_HB_32_8)+","+str(v_HB_32_9)+\
                ","+str(v_HB_32_10)+","+str(v_HB_32_11)+","+str(v_HB_32_12)+","+str(v_HB_32_13)+\
                ","+str(v_HB_32_14)+","+str(v_HB_32_15)+","+str(v_HB_32_16)+","+str(v_HB_32_17)+\
                ","+str(v_HB_32_18)+","+str(v_HB_32_19)+","+str(v_HB_32_20)+","+str(v_HB_32_21)+\
                ","+str(v_HB_32_22)+","+str(v_HB_32_23)+","+str(v_HB_32_24)+","+str(v_HB_32_25)+\
                ","+str(v_HB_32_26)+","+str(v_HB_32_27)+","+str(v_HB_32_28)+","+str(v_HB_32_29)+\
                ","+str(v_HB_32_30)+","+str(v_HB_32_31)+\
                ","+str(v_HB_31_2)+","+str(v_HB_31_3)+","+str(v_HB_31_4)+","+str(v_HB_31_5)+\
                ","+str(v_HB_31_6)+","+str(v_HB_31_7)+","+str(v_HB_31_8)+","+str(v_HB_31_9)+\
                ","+str(v_HB_31_10)+","+str(v_HB_31_11)+","+str(v_HB_31_12)+","+str(v_HB_31_13)+\
                ","+str(v_HB_31_14)+","+str(v_HB_31_15)+","+str(v_HB_31_16)+","+str(v_HB_31_17)+\
                ","+str(v_HB_31_18)+","+str(v_HB_31_19)+","+str(v_HB_31_20)+","+str(v_HB_31_21)+\
                ","+str(v_HB_31_22)+","+str(v_HB_31_23)+","+str(v_HB_31_24)+","+str(v_HB_31_25)+\
                ","+str(v_HB_31_26)+","+str(v_HB_31_27)+","+str(v_HB_31_28)+","+str(v_HB_31_29)+\
                ","+str(v_HB_31_30)+\
                ","+str(v_HB_30_2)+","+str(v_HB_30_3)+","+str(v_HB_30_4)+","+str(v_HB_30_5)+\
                ","+str(v_HB_30_6)+","+str(v_HB_30_7)+","+str(v_HB_30_8)+","+str(v_HB_30_9)+\
                ","+str(v_HB_30_10)+","+str(v_HB_30_11)+","+str(v_HB_30_12)+","+str(v_HB_30_13)+\
                ","+str(v_HB_30_14)+","+str(v_HB_30_15)+","+str(v_HB_30_16)+","+str(v_HB_30_17)+\
                ","+str(v_HB_30_18)+","+str(v_HB_30_19)+","+str(v_HB_30_20)+","+str(v_HB_30_21)+\
                ","+str(v_HB_30_22)+","+str(v_HB_30_23)+","+str(v_HB_30_24)+","+str(v_HB_30_25)+\
                ","+str(v_HB_30_26)+","+str(v_HB_30_27)+","+str(v_HB_30_28)+","+str(v_HB_30_29)+\
                ","+str(v_HB_29_2)+","+str(v_HB_29_3)+","+str(v_HB_29_4)+","+str(v_HB_29_5)+\
                ","+str(v_HB_29_6)+","+str(v_HB_29_7)+","+str(v_HB_29_8)+","+str(v_HB_29_9)+\
                ","+str(v_HB_29_10)+","+str(v_HB_29_11)+","+str(v_HB_29_12)+","+str(v_HB_29_13)+\
                ","+str(v_HB_29_14)+","+str(v_HB_29_15)+","+str(v_HB_29_16)+","+str(v_HB_29_17)+\
                ","+str(v_HB_29_18)+","+str(v_HB_29_19)+","+str(v_HB_29_20)+","+str(v_HB_29_21)+\
                ","+str(v_HB_29_22)+","+str(v_HB_29_23)+","+str(v_HB_29_24)+","+str(v_HB_29_25)+\
                ","+str(v_HB_29_26)+","+str(v_HB_29_27)+","+str(v_HB_29_28)+\
                ","+str(v_HB_28_2)+","+str(v_HB_28_3)+","+str(v_HB_28_4)+","+str(v_HB_28_5)+\
                ","+str(v_HB_28_6)+","+str(v_HB_28_7)+","+str(v_HB_28_8)+","+str(v_HB_28_9)+\
                ","+str(v_HB_28_10)+","+str(v_HB_28_11)+","+str(v_HB_28_12)+","+str(v_HB_28_13)+\
                ","+str(v_HB_28_14)+","+str(v_HB_28_15)+","+str(v_HB_28_16)+","+str(v_HB_28_17)+\
                ","+str(v_HB_28_18)+","+str(v_HB_28_19)+","+str(v_HB_28_20)+","+str(v_HB_28_21)+\
                ","+str(v_HB_28_22)+","+str(v_HB_28_23)+","+str(v_HB_28_24)+","+str(v_HB_28_25)+\
                ","+str(v_HB_28_26)+","+str(v_HB_28_27)+\
                ","+str(v_HB_27_2)+","+str(v_HB_27_3)+","+str(v_HB_27_4)+","+str(v_HB_27_5)+\
                ","+str(v_HB_27_6)+","+str(v_HB_27_7)+","+str(v_HB_27_8)+","+str(v_HB_27_9)+\
                ","+str(v_HB_27_10)+","+str(v_HB_27_11)+","+str(v_HB_27_12)+","+str(v_HB_27_13)+\
                ","+str(v_HB_27_14)+","+str(v_HB_27_15)+","+str(v_HB_27_16)+","+str(v_HB_27_17)+\
                ","+str(v_HB_27_18)+","+str(v_HB_27_19)+","+str(v_HB_27_20)+","+str(v_HB_27_21)+\
                ","+str(v_HB_27_22)+","+str(v_HB_27_23)+","+str(v_HB_27_24)+","+str(v_HB_27_25)+\
                ","+str(v_HB_27_26)+\
                ","+str(v_HB_26_2)+","+str(v_HB_26_3)+","+str(v_HB_26_4)+","+str(v_HB_26_5)+\
                ","+str(v_HB_26_6)+","+str(v_HB_26_7)+","+str(v_HB_26_8)+","+str(v_HB_26_9)+\
                ","+str(v_HB_26_10)+","+str(v_HB_26_11)+","+str(v_HB_26_12)+","+str(v_HB_26_13)+\
                ","+str(v_HB_26_14)+","+str(v_HB_26_15)+","+str(v_HB_26_16)+","+str(v_HB_26_17)+\
                ","+str(v_HB_26_18)+","+str(v_HB_26_19)+","+str(v_HB_26_20)+","+str(v_HB_26_21)+\
                ","+str(v_HB_26_22)+","+str(v_HB_26_23)+","+str(v_HB_26_24)+","+str(v_HB_26_25)+\
                ","+str(v_HB_25_2)+","+str(v_HB_25_3)+","+str(v_HB_25_4)+","+str(v_HB_25_5)+\
                ","+str(v_HB_25_6)+","+str(v_HB_25_7)+","+str(v_HB_25_8)+","+str(v_HB_25_9)+\
                ","+str(v_HB_25_10)+","+str(v_HB_25_11)+","+str(v_HB_25_12)+","+str(v_HB_25_13)+\
                ","+str(v_HB_25_14)+","+str(v_HB_25_15)+","+str(v_HB_25_16)+","+str(v_HB_25_17)+\
                ","+str(v_HB_25_18)+","+str(v_HB_25_19)+","+str(v_HB_25_20)+","+str(v_HB_25_21)+\
                ","+str(v_HB_25_22)+","+str(v_HB_25_23)+","+str(v_HB_25_24)+\
                ","+str(v_HB_24_2)+","+str(v_HB_24_3)+","+str(v_HB_24_4)+","+str(v_HB_24_5)+\
                ","+str(v_HB_24_6)+","+str(v_HB_24_7)+","+str(v_HB_24_8)+","+str(v_HB_24_9)+\
                ","+str(v_HB_24_10)+","+str(v_HB_24_11)+","+str(v_HB_24_12)+","+str(v_HB_24_13)+\
                ","+str(v_HB_24_14)+","+str(v_HB_24_15)+","+str(v_HB_24_16)+","+str(v_HB_24_17)+\
                ","+str(v_HB_24_18)+","+str(v_HB_24_19)+","+str(v_HB_24_20)+","+str(v_HB_24_21)+\
                ","+str(v_HB_24_22)+","+str(v_HB_24_23)+\
                ","+str(v_HB_23_2)+","+str(v_HB_23_3)+","+str(v_HB_23_4)+","+str(v_HB_23_5)+\
                ","+str(v_HB_23_6)+","+str(v_HB_23_7)+","+str(v_HB_23_8)+","+str(v_HB_23_9)+\
                ","+str(v_HB_23_10)+","+str(v_HB_23_11)+","+str(v_HB_23_12)+","+str(v_HB_23_13)+\
                ","+str(v_HB_23_14)+","+str(v_HB_23_15)+","+str(v_HB_23_16)+","+str(v_HB_23_17)+\
                ","+str(v_HB_23_18)+","+str(v_HB_23_19)+","+str(v_HB_23_20)+","+str(v_HB_23_21)+\
                ","+str(v_HB_23_22)+\
                ","+str(v_HB_22_2)+","+str(v_HB_22_3)+","+str(v_HB_22_4)+","+str(v_HB_22_5)+\
                ","+str(v_HB_22_6)+","+str(v_HB_22_7)+","+str(v_HB_22_8)+","+str(v_HB_22_9)+\
                ","+str(v_HB_22_10)+","+str(v_HB_22_11)+","+str(v_HB_22_12)+","+str(v_HB_22_13)+\
                ","+str(v_HB_22_14)+","+str(v_HB_22_15)+","+str(v_HB_22_16)+","+str(v_HB_22_17)+\
                ","+str(v_HB_22_18)+","+str(v_HB_22_19)+","+str(v_HB_22_20)+","+str(v_HB_22_21)+\
                ","+str(v_HB_21_2)+","+str(v_HB_21_3)+","+str(v_HB_21_4)+","+str(v_HB_21_5)+\
                ","+str(v_HB_21_6)+","+str(v_HB_21_7)+","+str(v_HB_21_8)+","+str(v_HB_21_9)+\
                ","+str(v_HB_21_10)+","+str(v_HB_21_11)+","+str(v_HB_21_12)+","+str(v_HB_21_13)+\
                ","+str(v_HB_21_14)+","+str(v_HB_21_15)+","+str(v_HB_21_16)+","+str(v_HB_21_17)+\
                ","+str(v_HB_21_18)+","+str(v_HB_21_19)+","+str(v_HB_21_20)+\
                ","+str(v_HB_20_2)+","+str(v_HB_20_3)+","+str(v_HB_20_4)+","+str(v_HB_20_5)+\
                ","+str(v_HB_20_6)+","+str(v_HB_20_7)+","+str(v_HB_20_8)+","+str(v_HB_20_9)+\
                ","+str(v_HB_20_10)+","+str(v_HB_20_11)+","+str(v_HB_20_12)+","+str(v_HB_20_13)+\
                ","+str(v_HB_20_14)+","+str(v_HB_20_15)+","+str(v_HB_20_16)+","+str(v_HB_20_17)+\
                ","+str(v_HB_20_18)+","+str(v_HB_20_19)+\
                ","+str(v_HB_19_2)+","+str(v_HB_19_3)+","+str(v_HB_19_4)+","+str(v_HB_19_5)+\
                ","+str(v_HB_19_6)+","+str(v_HB_19_7)+","+str(v_HB_19_8)+","+str(v_HB_19_9)+\
                ","+str(v_HB_19_10)+","+str(v_HB_19_11)+","+str(v_HB_19_12)+","+str(v_HB_19_13)+\
                ","+str(v_HB_19_14)+","+str(v_HB_19_15)+","+str(v_HB_19_16)+","+str(v_HB_19_17)+\
                ","+str(v_HB_19_18)+\
                ","+str(v_HB_18_2)+","+str(v_HB_18_3)+","+str(v_HB_18_4)+","+str(v_HB_18_5)+\
                ","+str(v_HB_18_6)+","+str(v_HB_18_7)+","+str(v_HB_18_8)+","+str(v_HB_18_9)+\
                ","+str(v_HB_18_10)+","+str(v_HB_18_11)+","+str(v_HB_18_12)+","+str(v_HB_18_13)+\
                ","+str(v_HB_18_14)+","+str(v_HB_18_15)+","+str(v_HB_18_16)+","+str(v_HB_18_17)+\
                ","+str(v_HB_17_2)+","+str(v_HB_17_3)+","+str(v_HB_17_4)+","+str(v_HB_17_5)+\
                ","+str(v_HB_17_6)+","+str(v_HB_17_7)+","+str(v_HB_17_8)+","+str(v_HB_17_9)+\
                ","+str(v_HB_17_10)+","+str(v_HB_17_11)+","+str(v_HB_17_12)+","+str(v_HB_17_13)+\
                ","+str(v_HB_17_14)+","+str(v_HB_17_15)+","+str(v_HB_17_16)+\
                ","+str(v_HB_16_2)+","+str(v_HB_16_3)+","+str(v_HB_16_4)+","+str(v_HB_16_5)+\
                ","+str(v_HB_16_6)+","+str(v_HB_16_7)+","+str(v_HB_16_8)+","+str(v_HB_16_9)+\
                ","+str(v_HB_16_10)+","+str(v_HB_16_11)+","+str(v_HB_16_12)+","+str(v_HB_16_13)+\
                ","+str(v_HB_16_14)+","+str(v_HB_16_15)+\
                ","+str(v_HB_15_2)+","+str(v_HB_15_3)+","+str(v_HB_15_4)+","+str(v_HB_15_5)+\
                ","+str(v_HB_15_6)+","+str(v_HB_15_7)+","+str(v_HB_15_8)+","+str(v_HB_15_9)+\
                ","+str(v_HB_15_10)+","+str(v_HB_15_11)+","+str(v_HB_15_12)+","+str(v_HB_15_13)+\
                ","+str(v_HB_15_14)+\
                ","+str(v_HB_14_2)+","+str(v_HB_14_3)+","+str(v_HB_14_4)+","+str(v_HB_14_5)+\
                ","+str(v_HB_14_6)+","+str(v_HB_14_7)+","+str(v_HB_14_8)+","+str(v_HB_14_9)+\
                ","+str(v_HB_14_10)+","+str(v_HB_14_11)+","+str(v_HB_14_12)+","+str(v_HB_14_13)+\
                ","+str(v_HB_13_2)+","+str(v_HB_13_3)+","+str(v_HB_13_4)+","+str(v_HB_13_5)+\
                ","+str(v_HB_13_6)+","+str(v_HB_13_7)+","+str(v_HB_13_8)+","+str(v_HB_13_9)+\
                ","+str(v_HB_13_10)+","+str(v_HB_13_11)+","+str(v_HB_13_12)+\
                ","+str(v_HB_12_2)+","+str(v_HB_12_3)+","+str(v_HB_12_4)+","+str(v_HB_12_5)+\
                ","+str(v_HB_12_6)+","+str(v_HB_12_7)+","+str(v_HB_12_8)+","+str(v_HB_12_9)+\
                ","+str(v_HB_12_10)+","+str(v_HB_12_11)+\
                ","+str(v_HB_11_2)+","+str(v_HB_11_3)+","+str(v_HB_11_4)+","+str(v_HB_11_5)+\
                ","+str(v_HB_11_6)+","+str(v_HB_11_7)+","+str(v_HB_11_8)+","+str(v_HB_11_9)+\
                ","+str(v_HB_11_10)+\
                ","+str(v_HB_10_2)+","+str(v_HB_10_3)+","+str(v_HB_10_4)+","+str(v_HB_10_5)+\
                ","+str(v_HB_10_6)+","+str(v_HB_10_7)+","+str(v_HB_10_8)+","+str(v_HB_10_9)+\
                ","+str(v_HB_9_2)+","+str(v_HB_9_3)+","+str(v_HB_9_4)+","+str(v_HB_9_5)+\
                ","+str(v_HB_9_6)+","+str(v_HB_9_7)+","+str(v_HB_9_8)+\
                ","+str(v_HB_8_2)+","+str(v_HB_8_3)+","+str(v_HB_8_4)+","+str(v_HB_8_5)+\
                ","+str(v_HB_8_6)+","+str(v_HB_8_7)+\
                ","+str(v_HB_7_2)+","+str(v_HB_7_3)+","+str(v_HB_7_4)+","+str(v_HB_7_5)+\
                ","+str(v_HB_7_6)+\
                ","+str(v_HB_6_2)+","+str(v_HB_6_3)+","+str(v_HB_6_4)+","+str(v_HB_6_5)+\
                ","+str(v_HB_5_2)+","+str(v_HB_5_3)+","+str(v_HB_5_4)+\
                ","+str(v_HB_4_2)+","+str(v_HB_4_3)+\
                ","+str(v_HB_3_2)
                
                aux_line_LJ_HB = aux_line_LJ+aux_line_HB
            
                # Write line
                self.fo2.write(str(line[1])+","+str(line[2])+","+str(line[3])+","+str(line[4])+\
                aux_line_LJ_HB+\
                ","+str(v_Elec)+","+str(v_Sol)+","+str(number_torsions)+","+str(exp_aff)+"\n")
        
                # Write line
                self.fo3.write("[000]"+str(line[2])+"_"+aux+" ["+str(line[3])+"]"+\
                aux_line_LJ_HB+\
                ","+str(v_Elec)+","+str(v_Sol)+","+str(number_torsions)+","+str(exp_aff)+"\n")
                
                # Write line for Lennard-Jones potentials
                self.fo4.write(str(line[1])+","+str(line[2])+","+str(line[3])+","+str(line[4])+\
                aux_line_LJ+\
                ","+str(v_Elec)+","+str(v_Sol)+","+str(number_torsions)+","+str(exp_aff)+"\n")
                
                # Write line for hydrogen-bond potentials
                self.fo5.write(str(line[1])+","+str(line[2])+","+str(line[3])+","+str(line[4])+\
                aux_line_HB+\
                ","+str(v_Elec)+","+str(v_Sol)+","+str(number_torsions)+","+str(exp_aff)+"\n")
                
                # Write line for Lennard-Jones potentials
                self.fo6.write("[000]"+str(line[2])+"_"+aux+" ["+str(line[3])+"]"+\
                aux_line_LJ+\
                ","+str(v_Elec)+","+str(v_Sol)+","+str(number_torsions)+","+str(exp_aff)+"\n")
                
                # Write line for hydrogen-bond potentials
                self.fo7.write("[000]"+str(line[2])+"_"+aux+" ["+str(line[3])+"]"+\
                aux_line_LJ+\
                ","+str(v_Elec)+","+str(v_Sol)+","+str(number_torsions)+","+str(exp_aff)+"\n")
        
        # Close files
        self.fo0.close()
        self.fo2.close()
        self.fo3.close()
        self.fo4.close()
        self.fo5.close()
        self.fo6.close()
        self.fo7.close()
        print("\nDone!")

        ##########################################################################
        # For plotting (for comparisons sake)
        # You may comment(#) all lines below
        # Define arguments for plot_pot() method
        #print("\nPlotting...")
        #x_label = "r($\AA$)"        # x-axis label
        #y_label = "V(r)(Kcal/mol)"  # y-axis label
        # For LJ
        #type_pot = "LJ"             # Type of potential
        #r_min = 2.8                 # Minimum value for r (interatomic distance) in Angstrom
        #r_max = 10                  # Maximum value for r (interatomic distance) in Angstrom
        #reqm_i  = 3.5               # sum of vdW radii of two like atoms (in Angstrom) (NA atom)
        #epsilon_i = 0.16            # Well depth (in Kcal/mol) (NA atom)
        #reqm_j  = 3.2               # sum of vdW radii of two like atoms (in Angstrom) (OA atom)
        #epsilon_j = 0.20            # Well depth (in Kcal/mol) (OA atom)
        #m = 6                       # Attraction expoent
        #n = 12                      # Repulsion expoent
        # For HB/ALL
        #type_pot = "ALL"            # Type of potential
        #r_min = 0.2                 # Minimum value for r (interatomic distance) in Angstrom
        #r_max = 10                  # Maximum value for r (interatomic distance) in Angstrom
        #reqm_i  = 1.9               # H-bond radius (in Angstrom) (NA atom)
        #epsilon_i = 5.0             # Well depth of H-bond (in Kcal/mol) (NA atom)
        #reqm_j  = 1.9               # H-bond radius (in Angstrom) (NA atom) (OA atom)
        #epsilon_j = 5.0             # Well depth of H-bond (in Kcal/mol) (OA atom)
        #m = 10                      # Attraction expoent
        #n = 12                      # Repulsion expoent
        # Invoking plot_plot() method
        #pot.plot_pot(type_pot,x_label,y_label,r_min,r_max,reqm_i,epsilon_i,reqm_j,epsilon_j,m,n)
        
        #input()

def main():
    # Instantiate an object of the SFexplorer class
    space = SFexplorer()

    space.read_input()

    space.read_data()
    
    space.write_energy()

main()
